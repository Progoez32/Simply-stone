function ssaToggle(btn) {
    var answer = btn.nextElementSibling;
    var isOpen = answer.classList.contains('open');

    // Close all
    document.querySelectorAll('.ssa-faq-a').forEach(function(a) {
        a.classList.remove('open');
    });
    document.querySelectorAll('.ssa-faq-q').forEach(function(q) {
        q.classList.remove('open');
    });

    // Open clicked if it was closed
    if (!isOpen) {
        answer.classList.add('open');
        btn.classList.add('open');
    }
}