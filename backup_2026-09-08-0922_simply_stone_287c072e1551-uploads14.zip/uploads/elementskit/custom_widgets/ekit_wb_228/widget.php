<?php

namespace Elementor;

defined('ABSPATH') || exit;

class Ekit_Wb_228 extends Widget_Base {

	public function __construct($data = [], $args = null) {
		parent::__construct($data, $args);

		wp_register_style( 'ekit-wb-228-style-handle', 'http://stone1.local/wp-content/uploads/elementskit/custom_widgets/ekit_wb_228/style.css');
		wp_register_script( 'ekit-wb-228-script-handle', 'http://stone1.local/wp-content/uploads/elementskit/custom_widgets/ekit_wb_228/script.js', [ 'elementor-frontend' ], '1.0.0', true );
	}


	public function get_style_depends() {
		return [ 'ekit-wb-228-style-handle' ];
	}


	public function get_script_depends() {
		return [ 'ekit-wb-228-script-handle' ];
	}

	public function get_name() {
		return 'ekit_wb_228';
	}


	public function get_title() {
		return esc_html__( 'New Widget', 'elementskit-lite' );
	}


	public function get_categories() {
		return ['basic'];
	}


	public function get_icon() {
		return 'eicon-cog';
	}


	protected function register_controls() {

		$this->start_controls_section(
			'content_section_228_0',
			array(
				'label' => esc_html__( 'FAQ', 'elementskit-lite' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
<div class="ssa-faq">
    <div class="ssa-faq-item">
        <button class="ssa-faq-q" onclick="ssaToggle(this)">
            What stones do you work with?
            <span class="ssa-faq-icon">+</span>
        </button>
        <div class="ssa-faq-a">
            <p>We work with a wide range of semi-precious stones including labradorite, amethyst, rose quartz, moonstone, turquoise, and many more.</p>
        </div>
    </div>
    <div class="ssa-faq-item">
        <button class="ssa-faq-q" onclick="ssaToggle(this)">
            Can I send my own stone?
            <span class="ssa-faq-icon">+</span>
        </button>
        <div class="ssa-faq-a">
            <p>Absolutely! You can send us your own stone and we will craft it into a beautiful piece of jewelry with custom engraving.</p>
        </div>
    </div>
    <div class="ssa-faq-item">
        <button class="ssa-faq-q" onclick="ssaToggle(this)">
            How long does a custom order take?
            <span class="ssa-faq-icon">+</span>
        </button>
        <div class="ssa-faq-a">
            <p>Custom orders typically take 2–3 weeks depending on complexity. We will keep you updated throughout the process.</p>
        </div>
    </div>
    <div class="ssa-faq-item">
        <button class="ssa-faq-q" onclick="ssaToggle(this)">
            Do you offer worldwide shipping?
            <span class="ssa-faq-icon">+</span>
        </button>
        <div class="ssa-faq-a">
            <p>Yes! We ship worldwide. Free shipping is included on all custom orders over $100.</p>
        </div>
    </div>
    <div class="ssa-faq-item">
        <button class="ssa-faq-q" onclick="ssaToggle(this)">
            What is your return policy?
            <span class="ssa-faq-icon">+</span>
        </button>
        <div class="ssa-faq-a">
            <p>We offer a 30-day return policy on all standard items. Custom orders are non-refundable but we will work with you to make it right.</p>
        </div>
    </div>
</div>
		<?php
	}


}
