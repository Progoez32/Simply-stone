(function () {
  function initFAQ() {
    var buttons = document.querySelectorAll('.ssa-faq-q');
    buttons.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var icon = this.querySelector('.ssa-faq-icon');
        var ans = this.nextElementSibling;
        var isOpen = ans.classList.contains('open');

        // Close all
        document.querySelectorAll('.ssa-faq-a.open').forEach(function (a) {
          a.classList.remove('open');
          a.previousElementSibling
            .querySelector('.ssa-faq-icon')
            .classList.remove('open');
        });

        // Open clicked if it was closed
        if (!isOpen) {
          ans.classList.add('open');
          icon.classList.add('open');
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initFAQ);
  } else {
    initFAQ();
  }
})();