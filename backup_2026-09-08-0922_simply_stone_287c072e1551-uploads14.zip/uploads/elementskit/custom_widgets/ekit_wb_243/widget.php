<?php

namespace Elementor;

defined('ABSPATH') || exit;

class Ekit_Wb_243 extends Widget_Base {

	public function __construct($data = [], $args = null) {
		parent::__construct($data, $args);

		wp_register_style( 'ekit-wb-243-style-handle', 'https://stone1.progoez.com/wp-content/uploads/elementskit/custom_widgets/ekit_wb_243/style.css');
		wp_register_script( 'ekit-wb-243-script-handle', 'https://stone1.progoez.com/wp-content/uploads/elementskit/custom_widgets/ekit_wb_243/script.js', [ 'elementor-frontend' ], '1.0.0', true );
	}


	public function get_style_depends() {
		return [ 'ekit-wb-243-style-handle' ];
	}


	public function get_script_depends() {
		return [ 'ekit-wb-243-script-handle' ];
	}

	public function get_name() {
		return 'ekit_wb_243';
	}


	public function get_title() {
		return esc_html__( 'FAQ New', 'elementskit-lite' );
	}


	public function get_categories() {
		return ['basic'];
	}


	public function get_icon() {
		return 'eicon-cog';
	}


	protected function register_controls() {

		$this->start_controls_section(
			'content_section_243_0',
			array(
				'label' => esc_html__( 'FAQ', 'elementskit-lite' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->end_controls_section();

	}


	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
<div class="ssa-faq">
  <div class="ssa-faq-header">
    <h2 class="ssa-faq-title"><?php echo isset($settings["ekit_wb_243_faq_title"]) ? wp_kses_post($settings["ekit_wb_243_faq_title"]) : ""; ?></h2>
    <hr class="ssa-faq-divider" />
  </div>
  <div class="ssa-faq-list"><div class="ssa-faq-item">
      <button class="ssa-faq-q"><?php echo isset($settings["ekit_wb_243_question"]) ? wp_kses_post($settings["ekit_wb_243_question"]) : ""; ?><span class="ssa-faq-icon">+</span>
      </button>
      <div class="ssa-faq-a"><?php echo isset($settings["ekit_wb_243_answer"]) ? wp_kses_post($settings["ekit_wb_243_answer"]) : ""; ?></div>
    </div></div>
</div>
		<?php
	}


}
